# Sibling-binding RHS in on-clauses (`on: %{field: %{as | at: %{name => sibling_field}}}`)

## Task

Make this shape produce the SQL on its right:

```elixir
on: %{game_id: %{as: %{latest_game_id: :game_id}}}
# outer.game_id == latest_game_id_binding.game_id

on: %{game_id: %{at: %{2 => :game_id}}}
# outer.game_id == (positional binding 2).game_id

on: %{game_id: %{as: %{a: :game_id, b: :game_id}}}
# outer.game_id == a.game_id AND outer.game_id == b.game_id   (multi-entry inner = AND)
```

This is what's needed to migrate `latest_rounds/3` (Round + `with_cte("latest_game_id")` + fragment join + on-clause `latest.game_id == round.game_id`) entirely as map params.

## Pattern to mirror

`apply_filter/6` in `lib/ecto_shorts/common_filters.ex` lines 396–414, specifically the `:as` / `:at` arm:

```elixir
key in [:as, :at] ->
  Enum.reduce(params, query, fn {next_key, next_value}, query_acc ->
    case resolve_binding_selector(query_acc, key, next_key) do
      :error -> query_acc
      {:ok, resolved} -> apply_filter(filter, source, query_acc, resolved, next_value, opts)
    end
  end)
```

What this does, line by line:

- `Enum.reduce(params, …)` — walks `params` once, getting an entry tuple per element. Works whether `params` is a map or keyword list. **No `%{…}` destructuring.**
- `fn {next_key, next_value}, query_acc -> …` — tuple-shape match on the entry. The entry's key and value are the tuple's two slots.
- `resolve_binding_selector(query_acc, key, next_key)` — validates the binding selector.
- `apply_filter(… resolved, next_value …)` — recurses with the retargeted scope and the inner value, all in one descent.

The on-clause analogue mirrors this same multi-level reduce. Each level is **one** `Enum.reduce`. Each entry is matched as a tuple `{tag, value}`, never as a map pattern `%{tag: value}`. No normalization step. No tagged-tuple IR.

## Constraints honoured

- **No new top-level params keys.** `:as` / `:at` already exist; only the position is new.
- **No new public functions or modules.** Every addition is `defp`.
- **No new internal tagged tuples.** Comparison dynamics emit directly via `Query.dynamic`; no `{:as, {…}}` IR tuple flows through anywhere.
- **No new code patterns / idioms.** Every new construct already exists in `common_filters/*` — multi-level `Enum.reduce` (apply_filter), per-binding-pattern macro template via `QueryBinding.query_binding_contracts/1` (distinct.ex:35-42, having.ex:47-55), `merge_dynamic/3` (already in join.ex).
- **Never destructure maps or keyword lists.** No `%{as: sm}` patterns. All access is through `Enum.reduce` over the container, with tuple-shape matches like `{:as, sm}` / `{:at, sm}` on the iterator entry.
- **One reduce per level.** Outer reduce walks `entries`. Per-entry reduce walks `value` (only when value is enumerable). Per-sibling-entry reduce walks `sibling_map`. Each level is one pass; each piece of data is handled at its own level. Mirrors `apply_filter` / `reduce_filters` recursion structure exactly.

## Files modified — only `lib/ecto_shorts/common_filters/join.ex`

### Replace `build_on_dynamic/5` (lines 276–283)

```elixir
defp build_on_dynamic(schema_source, query, selected_binding, entries, opts) do
  effective_source = resolve_source(schema_source, query, selected_binding)

  Enum.reduce(entries, nil, fn {field_key, value}, acc ->
    sub = reduce_on_value(query, effective_source, selected_binding, field_key, value, opts)
    merge_dynamic(acc, :and, sub)
  end)
end
```

### Append `reduce_on_value/6` — value-level reduce

The value is iterated with `Enum.reduce` exactly the way `apply_filter/6`'s `:as`/`:at` arm iterates `params`. Each entry comes out as a tuple and is matched by tuple shape — `{:as, sm}` / `{:at, sm}` for the sibling-RHS shapes, anything else as `{key, value}`. **No `%{…}` destructure.**

```elixir
defp reduce_on_value(query, effective_source, selected_binding, field_key, value, opts)
     when (is_map(value) and not is_struct(value)) or is_list(value) do
  Enum.reduce(value, nil, fn entry, acc ->
    sub = on_value_entry(query, effective_source, selected_binding, field_key, entry, opts)
    merge_dynamic(acc, :and, sub)
  end)
end

defp reduce_on_value(_query, effective_source, selected_binding, field_key, value, opts) do
  DynamicBuilders.build_dynamic(effective_source, selected_binding, {field_key, value}, opts)
end
```

### Append `on_value_entry/6` — per-value-entry dispatch

Three clauses. First two match the sibling-RHS tuple shapes; the third forwards everything else to `DynamicBuilders.build_dynamic/4` as a single-entry keyword list `[{key, value}]` so the existing value-shape vocabulary keeps working. Each clause is a *tuple* match, not a map match.

```elixir
defp on_value_entry(query, _effective_source, selected_binding, field_key, {:as, sibling_map}, _opts)
     when (is_map(sibling_map) and not is_struct(sibling_map)) or is_list(sibling_map) do
  reduce_sibling_rhs(query, selected_binding, field_key, :as, sibling_map)
end

defp on_value_entry(query, _effective_source, selected_binding, field_key, {:at, sibling_map}, _opts)
     when (is_map(sibling_map) and not is_struct(sibling_map)) or is_list(sibling_map) do
  reduce_sibling_rhs(query, selected_binding, field_key, :at, sibling_map)
end

defp on_value_entry(_query, effective_source, selected_binding, field_key, {key, value}, opts) do
  DynamicBuilders.build_dynamic(effective_source, selected_binding, {field_key, [{key, value}]}, opts)
end
```

### Append `reduce_sibling_rhs/5` — sibling-map reduce

This is the structural twin of `apply_filter`'s `:as`/`:at` arm. One `Enum.reduce`. Per-entry tuple match. `resolve_binding_selector/3` validates each binding selector; per-entry work emits one equality dynamic. **No `%{…}` destructure.**

```elixir
defp reduce_sibling_rhs(query, selected_binding, field_key, kind, sibling_map) do
  Enum.reduce(sibling_map, nil, fn entry, acc ->
    sub = sibling_pair_dynamic(query, selected_binding, field_key, kind, entry)
    merge_dynamic(acc, :and, sub)
  end)
end
```

### Append `sibling_pair_dynamic/5` — per-sibling-pair emission

```elixir
defp sibling_pair_dynamic(query, selected_binding, field_key, kind, {next_key, sibling_field})
     when is_atom(sibling_field) do
  case resolve_binding_selector(query, kind, next_key) do
    :error ->
      nil

    {:ok, resolved} ->
      lhs = field_dyn_for(selected_binding, field_key)
      rhs = field_dyn_for(resolved, sibling_field)
      Query.dynamic(^lhs == ^rhs)
  end
end

defp sibling_pair_dynamic(_query, _selected_binding, _field_key, kind, entry) do
  EctoShorts.Logger.warning(
    @logger_prefix,
    "Expected #{inspect(kind)} sibling entry to be {atom_or_position, atom_field}, got: #{inspect(entry)}; skipping"
  )

  nil
end
```

### Append `resolve_binding_selector/3` — copied verbatim from `common_filters.ex:484-510`

Same semantics, same warning, same range bound. Used by `sibling_pair_dynamic/5`.

```elixir
defp resolve_binding_selector(_query, :at, :first), do: {:ok, {:at, 1}}

defp resolve_binding_selector(query, :at, :last) do
  {:ok, {:at, CommonQuery.query_binding_count(query)}}
end

defp resolve_binding_selector(_query, :at, position) when is_integer(position) do
  max = Config.max_positional_bindings() || 10

  if position >= 1 and position <= max do
    {:ok, {:at, position}}
  else
    EctoShorts.Logger.warning(
      @logger_prefix,
      "Positional binding :at position #{position} is out of range " <>
        "(compiled max: #{max}). Filter skipped."
    )

    :error
  end
end

defp resolve_binding_selector(_query, key, inner_key), do: {:ok, {key, inner_key}}
```

### Append `field_dyn_for/2` — generated via `QueryBinding.query_binding_contracts/1`

Same template style as `distinct.ex:35-42`, `having.ex:47-55`, `select.ex` family. The existing `## Generated Functions` section in `join.ex:299` already calls `QueryBinding.query_binding_contracts(__MODULE__)` for `apply_join_expr/5`; reuse the same macro pair.

```elixir
{field_target_var, field_binding_patterns} = QueryBinding.query_binding_contracts(__MODULE__)

for {head, body} <- field_binding_patterns do
  defp field_dyn_for(unquote(head), field_name) do
    Query.dynamic([unquote_splicing(body)], field(unquote(field_target_var), ^field_name))
  end
end
```

If preferred, fold this into the existing module-level `QueryBinding.query_binding_contracts/1` invocation at `join.ex:301` so the macro runs once.

## Mapping each new function to `apply_filter`'s reference pattern

| `apply_filter/6` reference shape | New function in `join.ex` | What runs at the leaf |
|---|---|---|
| `reduce_filters` (line 392-394) — outer `Enum.reduce` over entries | `build_on_dynamic/5` outer reduce | per-entry call to `reduce_on_value/6` |
| `apply_filter/6` `cond` dispatch on entry key | `on_value_entry/6` clause heads (tuple match `{:as, _}` / `{:at, _}` / fallback) | sibling reduce vs. delegate to `DynamicBuilders` |
| `key in [:as, :at]` arm — inner `Enum.reduce` over `params` (lines 399-414) | `reduce_sibling_rhs/5` — inner `Enum.reduce` over `sibling_map` | per-pair call to `sibling_pair_dynamic/5` |
| `resolve_binding_selector(query_acc, key, next_key)` | `resolve_binding_selector(query, kind, next_key)` (verbatim copy) | identical |
| `:error -> query_acc` (skip) | `:error -> nil` (skip — `merge_dynamic` tolerates nil) | identical |
| `{:ok, resolved} -> apply_filter(… resolved, next_value …)` (recurse) | `{:ok, resolved} -> Query.dynamic(^lhs == ^rhs)` (emit) | the only structural swap: recurse vs. emit |

Same reduce shape, same selector resolution, same skip-on-error. The only difference is what the leaf does — apply_filter recurses for predicate filtering; on-clause emits a comparison dynamic for the join's `on:`.

## Files NOT modified

- `lib/ecto_shorts/common_filters.ex` — `apply_filter/6` already covers `:as` / `:at` for non-on predicates.
- `lib/ecto_shorts/dynamic_builders/postgres.ex` and sub-modules — out of scope.
- All other `common_filters/*.ex` — out of scope.

## Verification of the plan against your rules

I re-read `lib/ecto_shorts/common_filters/join.ex` end-to-end before writing this. Specifically:

- Every new function uses `Enum.reduce` over the container; none uses `%{…}` map destructure or `[{k, v}] = list` exact-shape matches.
- Every entry is matched as a tuple (`{field_key, value}` from outer iteration; `{:as, sm}` / `{:at, sm}` / `{key, value}` from value iteration; `{next_key, sibling_field}` from sibling iteration).
- No normalization step exists anywhere — there is no router clause that takes a map, produces a tuple IR, and re-enters another function. Each level emits its dynamic in place.
- No new tagged-tuple IR flows between functions; the only data passed between layers is the dynamic itself or the existing public-API selector tuples (`{:as, name}`, `{:at, pos}`) produced by `resolve_binding_selector/3`.
- No new public functions or modules. All additions are `defp` inside `join.ex`.
- The `field_dyn_for/2` macro template is the existing pattern from `distinct.ex:35-42` and `having.ex:47-55`. The QueryBinding contract is already imported in this file.

## Tests

Extend `test/ecto_shorts/common_filters/common_filters_join_test.exs` (the on-clause describe blocks around lines 614–697). Cover:

- Bare equality, named sibling: `on: %{game_id: %{as: %{latest_game_id: :game_id}}}` → `outer.game_id == latest_game_id.game_id`.
- Bare equality, positional sibling: `on: %{game_id: %{at: %{2 => :game_id}}}` → second positional binding.
- Multi-entry inner: AND of comparisons.
- Mixed sibling-RHS and literal-RHS entries in the same on-clause.
- Out-of-range `:at` — query unchanged, warning logged via `capture_log`.
- Non-atom sibling field — query unchanged, warning logged.
- **End-to-end motivating case**: `latest_rounds/3` rebuilt with map params, compared via `assert_sql/2` to the original Ecto-DSL form.

## Verification

1. `mix compile --warnings-as-errors`.
2. `mix test test/ecto_shorts/common_filters/common_filters_join_test.exs`.
3. `mix test`.
4. `mix credo`.
5. `mix dialyzer`.
6. End-to-end SQL check on the motivating case confirms the join's own `as:` binding resolves at runtime when the dynamic is interpolated through `field_dyn_for/2` (Ecto registers the new `as:` binding before `on:` is finalised — deps/ecto/lib/ecto/query/builder/join.ex:212–234).
