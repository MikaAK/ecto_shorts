# Plan: Multi-Adapter Test Structure

## Goal

Restructure the test suite so that each database adapter has its own directory of
tests. The CI pipeline runs each adapter as a separate hardcoded job with no matrix
strategy, no environment variables, and no parameterisation.

---

## Context

### What EctoShorts is

EctoShorts is an Elixir library (not an application) that provides a data-driven
query API on top of Ecto. It currently supports only one adapter:
`Ecto.Adapters.Postgres` via the `EctoShorts.DynamicBuilders.Postgres` module.

The library exposes a `dynamic_builder:` option on every public call site
(`CommonFilters.convert_params_to_filter/3`, `Actions.all/3`, etc.) that lets the
caller specify which dynamic expression builder to use at runtime. This is the hook
that makes per-adapter testing work.

### Current test layout

```
test/
  ecto_shorts_test.exs
  test_helper.exs
  ecto_shorts/
    actions/
      actions_batch_test.exs
      actions_bulk_test.exs
      actions_crud_test.exs
      actions_multi_test.exs
      actions_source_test.exs
      actions_transaction_test.exs
      error_test.exs
    common_filters/
      common_filters_aggregate_operators_test.exs
      common_filters_association_filter_test.exs
      common_filters_boolean_composition_test.exs
      common_filters_comparison_operators_test.exs
      common_filters_date_wrappers_test.exs
      common_filters_datetime_wrappers_test.exs
      common_filters_distinct_test.exs
      common_filters_enum_casting_test.exs
      common_filters_exclude_test.exs
      common_filters_field_types_opt_test.exs
      common_filters_first_test.exs
      common_filters_group_by_test.exs
      common_filters_having_test.exs
      common_filters_invalid_schema_field_test.exs
      common_filters_join_test.exs
      common_filters_last_test.exs
      common_filters_limit_test.exs
      common_filters_lock_test.exs
      common_filters_map_field_test.exs
      common_filters_negation_test.exs
      common_filters_offset_test.exs
      common_filters_order_modifier_test.exs
      common_filters_out_of_range_binding_test.exs
      common_filters_page_test.exs
      common_filters_parent_as_test.exs
      common_filters_preload_test.exs
      common_filters_put_query_prefix_test.exs
      common_filters_recursive_ctes_test.exs
      common_filters_select_merge_test.exs
      common_filters_select_test.exs
      common_filters_set_operation_test.exs
      common_filters_string_matching_test.exs
      common_filters_string_transformations_test.exs
      common_filters_subquery_test.exs
      common_filters_typed_value_casting_test.exs
      common_filters_update_test.exs
      common_filters_windows_test.exs
      common_filters_with_cte_test.exs
      common_filters_with_named_binding_test.exs
      common_filters_with_ties_test.exs
      update_expr_test.exs
    common_params/
      common_params_placeholders_test.exs
    dynamic_builders/
      postgres/
        array_expr_test.exs
        common_expr_test.exs
        map_expr_test.exs
        normalizer_test.exs
        scalar_expr_test.exs
      postgres_test.exs
    common_changes_test.exs
    common_filters_schemaless_test.exs
    common_filters_test.exs
    common_params_test.exs
    common_query_test.exs
    common_schema_test.exs
    config_test.exs
    dynamic_builders_test.exs
    logger_test.exs
    query_binding_test.exs
    query_builders_test.exs
    schema_helpers_test.exs
    source_test.exs
    testing_test.exs
    utils_test.exs
  support/
    data_case.ex
    repo.ex
    schema/
      book.ex
      comment.ex
      comment_abstract.ex
      composite_primary_key.ex
      enum_parent.ex
      enum_schema.ex
      post.ex
      post_abstract.ex
      post_abstract_has_schema_prefix.ex
      post_author.ex
      post_has_abstract_field_source.ex
      post_has_query_builder.ex
      post_has_schema_prefix.ex
      post_with_lock.ex
      user.ex
      user_abstract.ex
      user_data.ex
    test_dynamic_expression_adapter.ex
    test_no_op_query_provider.ex
    test_payload_probe_adapter.ex
    test_query_provider.ex
    test_unsupported_adapter.ex
    test_unsupported_repo.ex
```

### Current support files (verbatim)

**`test/support/repo.ex`**
```elixir
defmodule EctoShorts.Repo do
  @moduledoc false
  use Ecto.Repo,
    otp_app: :ecto_shorts,
    adapter: Ecto.Adapters.Postgres
end
```

**`test/support/data_case.ex`**
```elixir
defmodule EctoShorts.DataCase do
  use ExUnit.CaseTemplate

  alias Ecto.Adapters.SQL.Sandbox
  alias Ecto.Changeset

  using do
    quote do
      alias EctoShorts.Repo

      import Ecto
      import Ecto.Changeset
      import Ecto.Query
      import EctoShorts.DataCase
    end
  end

  setup tags do
    :ok = Sandbox.checkout(EctoShorts.Repo)

    unless tags[:async] do
      Sandbox.mode(EctoShorts.Repo, {:shared, self()})
    end

    :ok
  end

  def errors_on(changeset) do
    Changeset.traverse_errors(changeset, fn {message, opts} ->
      Enum.reduce(opts, message, fn {key, value}, acc ->
        String.replace(acc, "%{#{key}}", to_string(value))
      end)
    end)
  end
end
```

**`test/test_helper.exs`**
```elixir
ExUnit.start()

{:ok, _} = Application.ensure_all_started(:postgrex)
{:ok, _} = EctoShorts.Repo.start_link()
```

### Current CI workflow (coveralls.yml — representative)

```yaml
name: Coveralls
on: push
jobs:
  coveralls:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres
        env:
          POSTGRES_PASSWORD: postgres
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432
    steps:
      - uses: actions/checkout@v4
      - uses: actions/cache@v4
        with:
          path: |
            deps
            _build
          key: ${{ runner.os }}-mix-coveralls-${{ hashFiles('**/mix.lock') }}
          restore-keys: |
            ${{ runner.os }}-mix-coveralls-
      - uses: erlef/setup-beam@v1
        with:
          otp-version: 25.1.2
          elixir-version: 1.14.2
      - run: mix deps.get
      - run: CI=true MIX_ENV=test mix coveralls.json
      - name: Upload to codecov.io
        uses: codecov/codecov-action@v4
        with:
          token: ${{ secrets.CODECOV_TOKEN }}
```

---

## Target structure

```
test/
  adapters/
    postgres/
      actions/
        actions_batch_test.exs
        actions_bulk_test.exs
        actions_crud_test.exs
        actions_multi_test.exs
        actions_source_test.exs
        actions_transaction_test.exs
        error_test.exs
      common_filters/
        common_filters_aggregate_operators_test.exs
        ... (all 42 files from test/ecto_shorts/common_filters/)
        update_expr_test.exs
      common_params/
        common_params_placeholders_test.exs
      dynamic_builders/
        postgres/
          array_expr_test.exs
          common_expr_test.exs
          map_expr_test.exs
          normalizer_test.exs
          scalar_expr_test.exs
        postgres_test.exs
      common_changes_test.exs
      common_filters_schemaless_test.exs
      common_filters_test.exs
      common_params_test.exs
      common_query_test.exs
      common_schema_test.exs
      config_test.exs
      dynamic_builders_test.exs
      logger_test.exs
      query_binding_test.exs
      query_builders_test.exs
      schema_helpers_test.exs
      source_test.exs
      testing_test.exs
      utils_test.exs
  support/       ← unchanged, stays exactly as it is
  ecto_shorts_test.exs  ← stays at root
  test_helper.exs       ← stays at root
```

The `test/ecto_shorts/` directory is deleted after its contents are moved.

---

## What changes in each test file

Every file moved into `test/adapters/postgres/` needs one change only: add a
`@adapter` module attribute set to `EctoShorts.DynamicBuilders.Postgres` and pass
it as the `dynamic_builder:` key in every opts list.

### Before (current)

```elixir
defmodule EctoShorts.CommonFilters.ComparisonOperatorsTest do
  use ExUnit.Case, async: true
  use EctoShorts.Testing

  alias EctoShorts.CommonFilters
  alias EctoShorts.Schema.Post

  import Ecto.Query

  test "matches records where the field equals the value using ==" do
    expected = from(p in Post, where: p.id == ^1)
    q2 = CommonFilters.convert_params_to_filter(Post, %{id: %{==: 1}}, [])

    assert_sql(expected, q2)
  end
end
```

### After (postgres adapter)

```elixir
defmodule EctoShorts.Adapters.Postgres.CommonFilters.ComparisonOperatorsTest do
  use ExUnit.Case, async: true
  use EctoShorts.Testing

  alias EctoShorts.CommonFilters
  alias EctoShorts.Schema.Post

  import Ecto.Query

  @adapter EctoShorts.DynamicBuilders.Postgres

  test "matches records where the field equals the value using ==" do
    expected = from(p in Post, where: p.id == ^1)
    q2 = CommonFilters.convert_params_to_filter(Post, %{id: %{==: 1}}, dynamic_builder: @adapter)

    assert_sql(expected, q2)
  end
end
```

The two changes per file are:
1. Module name prefixed with `EctoShorts.Adapters.Postgres.`
2. `@adapter EctoShorts.DynamicBuilders.Postgres` added at module level, and every
   `[]` opts argument replaced with `[dynamic_builder: @adapter]` (or appended to
   existing opts keyword lists).

Tests that do not call `CommonFilters` or `Actions` (e.g. `config_test.exs`,
`logger_test.exs`, `utils_test.exs`) still get the module rename and `@adapter`
attribute but do not need opts changes.

---

## CI pipeline

Replace or supplement the existing `coveralls.yml` with a new workflow file at
`.github/workflows/test.yml`. Each adapter is a separate, fully hardcoded job. No
matrix strategy. No environment variables used to select the adapter.

```yaml
name: Test

on: push

jobs:
  test-postgres:
    runs-on: ubuntu-latest

    services:
      postgres:
        image: postgres
        env:
          POSTGRES_PASSWORD: postgres
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
      - uses: actions/checkout@v4

      - uses: actions/cache@v4
        with:
          path: |
            deps
            _build
          key: ${{ runner.os }}-mix-test-postgres-${{ hashFiles('**/mix.lock') }}
          restore-keys: |
            ${{ runner.os }}-mix-test-postgres-

      - uses: erlef/setup-beam@v1
        with:
          otp-version: 25.1.2
          elixir-version: 1.14.2

      - run: mix deps.get

      - run: CI=true MIX_ENV=test mix test test/adapters/postgres/

  # When a MySQL adapter is implemented in lib/, add the job below and create
  # test/adapters/mysql/ with its test files following the same pattern.
  #
  # test-mysql:
  #   runs-on: ubuntu-latest
  #   services:
  #     mysql:
  #       image: mysql:8
  #       env:
  #         MYSQL_ROOT_PASSWORD: root
  #         MYSQL_DATABASE: ecto_shorts_test
  #       ports:
  #         - 3306:3306
  #   steps:
  #     - uses: actions/checkout@v4
  #     - uses: erlef/setup-beam@v1
  #       with:
  #         otp-version: 25.1.2
  #         elixir-version: 1.14.2
  #     - run: mix deps.get
  #     - run: CI=true MIX_ENV=test mix test test/adapters/mysql/
  #
  # test-sqlite:
  #   runs-on: ubuntu-latest
  #   steps:
  #     - uses: actions/checkout@v4
  #     - uses: erlef/setup-beam@v1
  #       with:
  #         otp-version: 25.1.2
  #         elixir-version: 1.14.2
  #     - run: mix deps.get
  #     - run: CI=true MIX_ENV=test mix test test/adapters/sqlite/
```

---

## Step-by-step execution checklist

- [ ] Create directory `test/adapters/postgres/` and all subdirectories mirroring
      the current `test/ecto_shorts/` layout.

- [ ] Move every file from `test/ecto_shorts/` into its equivalent path under
      `test/adapters/postgres/`, preserving subdirectory structure.

- [ ] In every moved file:
  - Rename the module from `EctoShorts.X` to `EctoShorts.Adapters.Postgres.X`
  - Add `@adapter EctoShorts.DynamicBuilders.Postgres` at the top of the module
    body (after `use` and `alias` lines)
  - Replace every bare `[]` in the opts position of `convert_params_to_filter`,
    `Actions.all`, `Actions.get`, `Actions.create`, `Actions.update`,
    `Actions.delete`, and any other public API call that accepts opts, with
    `[dynamic_builder: @adapter]`
  - For calls that already have a non-empty opts keyword list, append
    `dynamic_builder: @adapter` to the existing list

- [ ] Delete the now-empty `test/ecto_shorts/` directory.

- [ ] Create `.github/workflows/test.yml` with the content shown in the CI section
      above.

- [ ] Run `mix test test/adapters/postgres/` locally and confirm all tests pass
      before committing.

---

## Rules for adding a new adapter in future

1. Implement the `EctoShorts.DynamicBuilder` behaviour for the new adapter in
   `lib/ecto_shorts/dynamic_builders/<adapter_name>.ex`.
2. Create `test/adapters/<adapter_name>/` and copy the full postgres test tree into
   it.
3. In every copied file, change `@adapter` to the new adapter module.
4. Adjust or remove any tests that rely on Postgres-specific SQL (array operators,
   JSONB, `ilike`, CTEs with `RECURSIVE`, window functions) that the new adapter
   does not support.
5. Add a new hardcoded job block to `.github/workflows/test.yml` for the new
   adapter, with the appropriate database service and
   `mix test test/adapters/<adapter_name>/`.
6. Uncomment and fill in the relevant commented-out job block already present in
   `test.yml` as a template.
