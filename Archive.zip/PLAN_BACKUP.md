# Fix `DynamicBuilders.Postgres`

## Problems

1. **Double traversal** — keyword list clause in `build_dynamic/4` does `Enum.map(&cast_value/2)` then `Enum.reduce`; bare-map `dispatch_expr` clause does `Enum.map` then `Enum.reduce`; map-field branch of `dispatch_field_expr` does the same.
2. **Circular dependency** — `build_quantified_query/3` calls `CommonFilters.convert_params_to_filter/3` from inside the expression builder.
3. **Normalization inside a routing function** — `dispatch_field_expr/6` has `canonical = cond do...` blocks that wrap bare values in `{:==, term}`.
4. **Exact-shape matches on variable-length collections** (5 locations) — `[{compare_op, value}] = params`, `[left, right]`, `[{pb, pf}] = Map.to_list(pb_map)`, `[{datetime_op, datetime_term}]`, `case Map.to_list(payload) do [{op, val}] ->`.

Also: `Types.cast` must be called once, at the boundary before the value enters a sub-module.

---

## Architectural rule — router owns normalization; sub-modules are pure dispatchers

The responsibility split is fixed and applies to every change below. Any earlier draft that violated this rule is rejected.

**The router (`walk/6`, `evaluate/6`, `evaluate_field/6` in `postgres.ex`) owns ALL normalization of public-API input shapes into the tuple IR that sub-modules consume.** Normalization means converting any map-form, keyword-list-form, or public-API wrapper shape into a canonical tuple. This includes every single-key-map wrapper a caller can express:

| Public-API shape | Router normalizes to |
|---|---|
| `{:date, %{add: params}}` / `{:datetime, %{ago: v}}` | `{:date, {:add, params}}` / `{:datetime, {:ago, v}}` |
| `{:parent_as, %{<binding_name> => <field_name>}}` | `{:parent_as, {<binding_name>, <field_name>}}` per entry, AND-merged across entries |
| `{:lower, v}` / `{:downcase, v}` | `{:lower, v}` (downcase aliased) |
| `{:upper, v}` / `{:upcase, v}` | `{:upper, v}` (upcase aliased) |
| `{op, %{field: "base"}}` | `{op, {:field, :base}}` (binary resolved to atom) |
| `{op, %{value: v}}` | `{op, {:value, v}}` |
| `{op, %{add: [...]}}` | `{op, {:add, [operand_ir, ...]}}` (recursive) |
| `{op, %{abs: %{field: "x"}}}` | `{op, {:abs, {:field, :x}}}` (recursive) |

The router resolves binary field names via `field_name_to_atom/3`, validates Operand arity, and calls `Types.cast` exactly once per leaf. By the time `evaluate_field/6` hands the term to a sub-module, every wrapper is a tuple, every inner operand is a tuple, every field reference is an atom.

**Sub-modules (`ScalarExpr`, `ArrayExpr`, `MapExpr`, `CommonExpr`) receive only fully-normalized tuple IR and perform pure pattern-dispatch.** They **must not**:

- Accept map-form input for any shape
- Call `Map.to_list/1`, `Keyword.new/1`, `Enum.into/2` with a map target, or any `normalize_*` helper
- Walk Operand trees for the purpose of IR translation
- Resolve field names from binaries to atoms
- Validate operand arity or emit arity warnings
- Own any RHS IR translation — field references, value wrappers, arithmetic operands, `parent_as` bindings, datetime wrappers are all tuple IR by the time they arrive

Every sub-module clause is `defp dispatch_expr(binding, key, {op, tuple_ir})` — one pattern per SQL shape. Recursive *code generation* for nested tuple IR (e.g. walking `{:add, [operand_tuple, ...]}` to emit `^a + ^b`) stays in the sub-module because it is not IR translation; it is tuple-to-SQL emission.

The line: if the helper converts form, it belongs in the router. If the helper consumes tuple IR and emits an `Ecto.Query.dynamic_expr/0`, it belongs in the sub-module.

---

## Architectural rule — accept map AND keyword-list everywhere a nested filter container is consumed

Every public-API position that takes a nested filter container (a wrapper inner, an Operand node, a multi-entry payload that fans out) **must accept either a map or a keyword list**. Callers in this codebase routinely write either form; rejecting one is a bug.

The pattern that satisfies this rule:

```elixir
defp evaluate(source, binding, key, negated, {wrapper, inner}, opts)
     when wrapper in @some_wrappers and
            ((is_map(inner) and not is_struct(inner)) or is_list(inner)) do
  if is_list(inner) and not Keyword.keyword?(inner) do
    nil
  else
    Enum.reduce(inner, nil, fn {k, v}, acc ->
      dyn = evaluate(source, binding, key, negated, {wrapper, {k, v}}, opts)
      merge_dynamic(acc, :and, dyn)
    end)
  end
end
```

`Enum.reduce` iterates `{k, v}` pairs identically over maps and keyword lists, so a single body handles both. The `is_list and not Keyword.keyword?` arm guards against non-keyword lists at the same position (e.g. `{:date, [1, 2, 3]}`), which would otherwise crash the destructure.

**Anti-pattern (REJECTED):**

```elixir
defp evaluate(_, _, _, _, {wrapper, inner}, _)
     when wrapper in @some_wrappers and is_map(inner) and not is_struct(inner) do
  ...
end
```

A map-only guard silently rejects every kwlist caller of the same wrapper. The rest of the evaluator falls through to a clause that treats the kwlist as an opaque value, producing wrong SQL or `nil` with no warning.

**Where this applies in `Postgres`:**

- Datetime wrapper inner (`{:date, inner}`, `{:datetime, inner}`)
- `parent_as` wrapper inner — both `{:parent_as, inner}` and `{op, {:parent_as, inner}}`
- Elements wrapper inner (`{:elements, {op, inner}}`)
- Operand-RHS comparison map (`{op, rhs}` where `op ∈ @comparison_operators`) — and the `operand_shape?/1` / `normalize_operand/3` helpers it dispatches to

Single-key Operand maps (`%{add: [...]}`) and single-key Operand kwlists (`[add: [...]]`) are equivalent. `operand_shape?/1` and `normalize_operand/3` accept both via the same `is_map or is_list` guard plus the same kwlist sanity check.

---

## Change 1 — Single traversal in `build_dynamic/4`

### Before (lines 141–177)

```elixir
def build_dynamic(source, selected_binding, {key, params}, opts) when is_list(params) do
  field_types = Keyword.get(opts, :field_types, [])

  field_type =
    Keyword.get(field_types, key) || CommonSchema.get_schema_reflection(source, :type, key)

  if Keyword.keyword?(params) do
    params
    |> Enum.map(&cast_value(field_type, &1))
    |> Enum.reduce(nil, fn entry, acc ->
      {merge_op, keyed_entry} =
        case entry do
          {op, term} when op in [:and, :or] -> {op, {key, term}}
          term -> {:and, {key, term}}
        end

      dyn = apply_expr(source, selected_binding, keyed_entry, opts)
      merge_dynamic(acc, merge_op, dyn)
    end)
    |> then(&merge_dynamic(nil, :and, &1))
  else
    casted = cast_value(field_type, params)
    dyn = apply_expr(source, selected_binding, {key, casted}, opts)
    merge_dynamic(nil, :and, dyn)
  end
end

def build_dynamic(source, selected_binding, {key, params}, opts) do
  field_types = Keyword.get(opts, :field_types, [])

  field_type =
    Keyword.get(field_types, key) || CommonSchema.get_schema_reflection(source, :type, key)

  casted = cast_value(field_type, params)
  dyn = apply_expr(source, selected_binding, {key, casted}, opts)
  merge_dynamic(nil, :and, dyn)
end
```

### After

```elixir
def build_dynamic(source, selected_binding, {key, params}, opts) when is_list(params) do
  if Keyword.keyword?(params) do
    Enum.reduce(params, nil, fn entry, acc ->
      {merge_op, inner} =
        case entry do
          {op, term} when op in [:and, :or] -> {op, term}
          term -> {:and, term}
        end

      dyn = apply_expr(source, selected_binding, {key, inner}, opts)
      merge_dynamic(acc, merge_op, dyn)
    end)
  else
    dyn = apply_expr(source, selected_binding, {key, params}, opts)
    merge_dynamic(nil, :and, dyn)
  end
end

def build_dynamic(source, selected_binding, {key, params}, opts) do
  dyn = apply_expr(source, selected_binding, {key, params}, opts)
  merge_dynamic(nil, :and, dyn)
end
```

**Why:** Single `Enum.reduce` replaces the `Enum.map |> Enum.reduce` pair. Field-type resolution moves out of `build_dynamic/4` — casting now happens once at the sub-module boundary in `dispatch_field_expr`, so `build_dynamic/4` no longer needs `field_type`.

---

## Change 2 — Move subquery construction out of `postgres.ex`

### Remove from `postgres.ex`

**Remove** `build_quantified_query/3` (lines 450–487), `subquery_spec?/1` (lines 489–497), and the `alias EctoShorts.CommonFilters` and `alias EctoShorts.CommonFilters.Select` lines.

**Remove** these two `dispatch_expr` clauses (lines 215–247):

```elixir
defp dispatch_expr(source, selected_binding, key, negated, {quantifier, payload}, opts)
     when quantifier in @quantifier_operators do
  if subquery_spec?(payload) do
    subquery = build_quantified_query(key, payload, opts)
    dispatch_field_expr(source, selected_binding, key, negated, {:==, {quantifier, subquery}}, opts)
  else
    canonical_payload =
      if is_map(payload) and not is_struct(payload) and not subquery_spec?(payload) do
        case Map.to_list(payload) do
          [{op, val}] ->
            canonical_op = if op in @short_ops, do: op_alias(op), else: op
            {canonical_op, val}

          _ ->
            payload
        end
      else
        payload
      end

    dispatch_field_expr(source, selected_binding, key, negated, {quantifier, canonical_payload}, opts)
  end
end

defp dispatch_expr(source, selected_binding, key, negated, {op, {quantifier, payload}}, opts)
     when quantifier in @quantifier_operators do
  if subquery_spec?(payload) do
    subquery = build_quantified_query(key, payload, opts)
    dispatch_field_expr(source, selected_binding, key, negated, {op, {quantifier, subquery}}, opts)
  else
    dispatch_field_expr(source, selected_binding, key, negated, {op, {quantifier, payload}}, opts)
  end
end
```

### Replace with (fan out multi-key payloads, no subquery branching)

```elixir
# Map payload — normalize to kwlist and re-enter (keyword-list branch fans out).
defp dispatch_expr(source, selected_binding, key, negated, {quantifier, payload}, opts)
     when quantifier in @quantifier_operators and is_map(payload) and not is_struct(payload) do
  dispatch_expr(source, selected_binding, key, negated, {quantifier, Map.to_list(payload)}, opts)
end

# Kwlist payload — one dyn per (op, v) pair, AND-merged.
defp dispatch_expr(source, selected_binding, key, negated, {quantifier, payload}, opts)
     when quantifier in @quantifier_operators and is_list(payload) do
  if Keyword.keyword?(payload) and payload !== [] do
    Enum.reduce(payload, nil, fn {op, val}, acc ->
      canonical_op = if op in @short_ops, do: op_alias(op), else: op
      dyn = dispatch_field_expr(source, selected_binding, key, negated, {quantifier, {canonical_op, val}}, opts)
      merge_dynamic(acc, :and, dyn)
    end)
  else
    dispatch_field_expr(source, selected_binding, key, negated, {quantifier, payload}, opts)
  end
end

# Tuple or pre-built Ecto.Query payload — canonicalize short op if present.
defp dispatch_expr(source, selected_binding, key, negated, {quantifier, payload}, opts)
     when quantifier in @quantifier_operators do
  canonical_payload =
    case payload do
      {op, v} when op in @short_ops -> {op_alias(op), v}
      other -> other
    end

  dispatch_field_expr(source, selected_binding, key, negated, {quantifier, canonical_payload}, opts)
end
```

**Why:** By the time a `{quantifier, payload}` reaches this clause, `CommonFilters` has already resolved any subquery spec and `payload` is either a built `Ecto.Query`, a tuple `{op, v}`, a map, or a kwlist. Maps normalize to kwlists via the first clause; kwlists fan out via `Enum.reduce` (one dyn per pair, AND-merged — no exact-shape single-pair assumption, no silent-drop accumulator). The second `dispatch_expr` clause (`{op, {quantifier, payload}}`) is redundant — `build_rhs_entry` plus the `{op, rhs_params}` clause in `dispatch_expr` already feed through to `dispatch_field_expr` with `{op, {quantifier, query}}` intact. Also addresses exact-shape match 4e.

**Entry-point contract:** `CommonFilters.convert_params_to_filter/3` is the only supported entry point for subquery specs. Direct callers of `DynamicBuilders.Postgres.build_dynamic/4` must pass a pre-built `Ecto.Query` in the `{:all, _}` / `{:any, _}` payload. Passing a spec directly is unsupported — `postgres.ex` no longer resolves specs.

### Add to `common_filters.ex`

**Add alias** to the existing alias block:
```elixir
alias EctoShorts.CommonFilters.Select
```

**Modify the `true ->` branch** of the cond block in `apply_filter/6` (line 455–457). This is the single fallback every field-level entry passes through regardless of which predicate filter (`:where`, `:or_where`, `:having`, `:or_having`) drove the call. One preprocessing step here resolves any subquery spec in the value before dispatching to `Builder`.

Before:
```elixir
true ->
  Builder.build_query(filter, source, query, selected_binding, {key, params}, opts)
```

After:
```elixir
true ->
  resolved = resolve_quantifier_subquery(key, params, opts)
  Builder.build_query(filter, source, query, selected_binding, {key, resolved}, opts)
```

**Add three private functions** at the bottom of `common_filters.ex`:

```elixir
defp resolve_quantifier_subquery(key, {quantifier, payload}, opts)
     when quantifier in [:all, :any] do
  if subquery_spec?(payload),
    do: {quantifier, build_quantified_subquery(key, payload, opts)},
    else: {quantifier, payload}
end

defp resolve_quantifier_subquery(key, {op, {quantifier, payload}}, opts)
     when quantifier in [:all, :any] do
  if subquery_spec?(payload),
    do: {op, {quantifier, build_quantified_subquery(key, payload, opts)}},
    else: {op, {quantifier, payload}}
end

defp resolve_quantifier_subquery(_key, params, _opts), do: params
```

**Add two more private functions** at the bottom of `common_filters.ex`:

```elixir
defp subquery_spec?(payload) when is_map(payload) and not is_struct(payload),
  do: Map.has_key?(payload, :from)

defp subquery_spec?(payload) when is_list(payload),
  do: Keyword.keyword?(payload) and Keyword.has_key?(payload, :from)

defp subquery_spec?(_payload), do: false

defp build_quantified_subquery(outer_key, params, opts)
     when is_map(params) and not is_struct(params) do
  build_quantified_subquery(outer_key, Map.to_list(params), opts)
end

defp build_quantified_subquery(outer_key, params, opts) do
  if Keyword.keyword?(params) do
    {source, params_without_from} = Keyword.pop(params, :from, [])
    {select_spec, where_params} = Keyword.pop(params_without_from, :select)

    select_term =
      case select_spec || outer_key do
        field when is_atom(field) and field !== nil ->
          field

        field when is_binary(field) ->
          fields = CommonSchema.get_schema_reflection(source, :fields) || []
          Enum.find(fields, &(Atom.to_string(&1) == field)) || outer_key

        params ->
          if (is_map(params) and not is_struct(params)) or Keyword.keyword?(params) do
            field_atom = params[:field]
            if is_atom(field_atom) and field_atom != nil, do: field_atom, else: outer_key
          else
            outer_key
          end
      end

    inner_query = convert_params_to_filter(source, where_params, opts)
    Select.build_query(:select, source, inner_query, {:as, nil}, select_term, opts)
  else
    EctoShorts.Logger.warning(
      @logger_prefix,
      "Expected a map or keyword list, got: #{inspect(params)}"
    )

    params
  end
end
```

---

## Change 3 — Remove normalization from `dispatch_field_expr`; call `Types.cast` once

### New `dispatch_expr` clause — insert before the fallback clause (line 396)

```elixir
# Plain non-keyword list — wrap as equality operand before routing to dispatch_field_expr
# so that dispatch_field_expr always receives an {op, value} tuple.
defp dispatch_expr(source, selected_binding, key, negated, term, opts)
     when is_list(term) and not Keyword.keyword?(term) do
  dispatch_field_expr(source, selected_binding, key, negated, {:==, term}, opts)
end
```

The existing scalar clause (line 263) already wraps non-tuple/non-list terms as `{:==, term}`. With this new clause, every caller of `dispatch_field_expr` passes an `{op, value}` tuple.

### Before (`dispatch_field_expr/6`, lines 400–448)

```elixir
defp dispatch_field_expr(source, selected_binding, key, negated, term, opts) do
  cond do
    invalid_schema_field?(source, key) ->
      EctoShorts.Logger.warning(
        @logger_prefix,
        "Field \"#{key}\" does not exist on schema #{inspect(CommonSchema.get_schema(source))}, skipping field reference"
      )

      nil

    map_field?(source, key, opts) ->
      case term do
        {op, values} when is_list(values) and values !== [] ->
          if Keyword.keyword?(values) do
            values
            |> Enum.map(fn kv -> MapExpr.dynamic_expr(selected_binding, key, negated, {op, kv}, opts) end)
            |> Enum.reduce(nil, &merge_dynamic(&2, :and, &1))
          else
            MapExpr.dynamic_expr(selected_binding, key, negated, term, opts)
          end

        _ ->
          MapExpr.dynamic_expr(selected_binding, key, negated, term, opts)
      end

    array_field?(source, key, opts) ->
      canonical =
        case term do
          {op, value} -> {op, value}
          nil -> {:==, nil}
          list when is_list(list) -> {:==, list}
          scalar -> {:==, scalar}
        end

      ArrayExpr.dynamic_expr(selected_binding, key, negated, canonical, opts)

    true ->
      canonical =
        case term do
          {op, value} -> {op, value}
          scalar -> {:==, scalar}
        end

      ScalarExpr.dynamic_expr(selected_binding, key, negated, canonical, opts)
  end
end
```

### After

```elixir
# Precondition: term is always an {op, tuple_ir} tuple. The walker wraps bare
# scalars and plain lists; the evaluator has already collapsed every map-form
# wrapper (datetime, parent_as, Operand RHS, transforms) into tuple IR. Types.cast
# is called here — the single call site in the entire module. Sub-modules receive
# fully-normalized tuple IR and perform pure pattern-dispatch; they do not translate
# wrappers, walk Operand trees, resolve field names, or validate arity.
defp evaluate_field(source, binding, key, negated, {op, raw_value}, opts) do
  field_type = resolve_field_type(source, key, opts)
  value = Types.cast(field_type, raw_value)

  cond do
    invalid_schema_field?(source, key) ->
      EctoShorts.Logger.warning(
        @logger_prefix,
        "Field \"#{key}\" does not exist on schema #{inspect(CommonSchema.get_schema(source))}, skipping field reference"
      )

      nil

    map_field?(field_type) ->
      MapExpr.dynamic_expr(binding, key, negated, {op, value}, opts)

    array_field?(field_type) ->
      ArrayExpr.dynamic_expr(binding, key, negated, {op, value}, opts)

    true ->
      ScalarExpr.dynamic_expr(binding, key, negated, {op, value}, opts)
  end
end
```

The keyword-list JSONB expansion (previously done inline by fanning out each `{k, v}` into separate `MapExpr.dynamic_expr` calls and AND-combining the dyns) is no longer needed here: the walker already fans out keyword-list values at the top-level field-value slot, so each `{op, inner}` arrives at `evaluate_field/6` one at a time. `MapExpr` receives one tuple IR per call and pattern-matches — it does not unwrap maps, call `Map.to_list`, or fan out anything.

### Also: simplify `array_field?` and `map_field?`

**Before** (lines 506–519) — re-resolved the field type inline:

```elixir
defp array_field?(source, key, opts) do
  case opts[:field_types] || CommonSchema.get_schema_reflection(source, :type, key) do
    {:array, _} -> true
    _ -> false
  end
end

defp map_field?(source, key, opts) do
  case opts[:field_types] || CommonSchema.get_schema_reflection(source, :type, key) do
    :map -> true
    {:map, _} -> true
    _ -> false
  end
end
```

**After** — take the already-resolved field type:

```elixir
defp array_field?({:array, _}), do: true
defp array_field?(_), do: false

defp map_field?(:map), do: true
defp map_field?({:map, _}), do: true
defp map_field?(_), do: false
```

### Also: add `resolve_field_type/3`

```elixir
defp resolve_field_type(source, key, opts) do
  field_types = Keyword.get(opts, :field_types, [])
  Keyword.get(field_types, key) || CommonSchema.get_schema_reflection(source, :type, key)
end
```

### Delete `cast_value/2` entirely

All 14 `cast_value/2` clauses (lines 521–584) are deleted. `Types.cast/2` is called exactly once in the entire module — inline in `evaluate_field/6` against the raw field value. Operand-aware casting shapes that `cast_value` previously handled (`{:in, [...]}`, `{:count, {op, v}}`, `{:all, {op, v}}`, `{:value, v}`, array inner types, `:integer` for `:count`, element-wise for lists) are dispatched by shape in the **evaluator**: when the evaluator pattern-matches those tuple IR shapes, it performs the relevant casting step before handing the normalized tuple to `evaluate_field/6`. Sub-modules receive already-cast values and do not re-cast.

Short-op aliasing (`:eq` → `:==`, etc.) happens inline in `walk/6` via `normalize_op/1` at each lift point.

Other wrapper-normalization steps (datetime wrapper map → datetime tuple IR, `parent_as` map → `{:parent_as, {b, f}}` tuple, Operand-shaped RHS map → recursive Operand tuple IR with binary field names resolved to atoms) happen inline in `evaluate/6` before the call to `evaluate_field/6`. See Change 7 for the Operand-normalization clauses and the "Wrapper normalization" subsection below for datetime and `parent_as`.

---

## Change 4 — Remove exact-shape matches (4 remaining locations; 4e is handled in Change 2)

### 4a. Aggregate shorthand list

**Before** (line 339):
```elixir
defp dispatch_expr(source, selected_binding, key, negated, {agg_fn, params}, opts)
     when agg_fn in @agg_fns and is_list(params) do
  [{compare_op, value}] = params
  dispatch_field_expr(source, selected_binding, key, negated, {agg_fn, {compare_op, value}}, opts)
end
```

**After**:
```elixir
defp dispatch_expr(source, selected_binding, key, negated, {agg_fn, params}, opts)
     when agg_fn in @agg_fns and is_list(params) do
  Enum.reduce(params, nil, fn {compare_op, value}, acc ->
    dyn = dispatch_field_expr(source, selected_binding, key, negated, {agg_fn, {compare_op, value}}, opts)
    merge_dynamic(acc, :and, dyn)
  end)
end
```

Each entry is applied and results AND-combined. Multi-entry input (e.g. `[gt: 5, lt: 100]`) produces `agg > 5 AND agg < 100`. Single-entry behaviour unchanged.

### 4b–4d. Exact-shape matches in deleted RHS-translation functions

The remaining exact-shape matches (arithmetic operands, `:parent_as` inner map, datetime wrapper list) all live inside `build_rhs_entry/4`, `build_rhs_expr/3`, `resolve_datetime_wrapper/3`, and `resolve_datetime_node/3`. These functions are all deleted: RHS IR translation is now the router's responsibility (in `evaluate/6`). The exact-shape matches disappear with the functions that contained them.

Where the shapes are now handled:

| Previous location | Shape | New home |
|---|---|---|
| `build_rhs_entry(src, op, [left, right], opts) when op in [:+, :-, :*, :/]` | `[left, right]` | Deleted — the legacy `:arithmetic` wrapper is gone (Change 7). Operand RHS uses the new grammar; the router's `normalize_operand/3` handles all arithmetic trees, validates arity (skip + warn, never raise), and emits tuple IR. `ScalarExpr` pattern-matches the tuple IR. |
| `build_rhs_entry(_src, :parent_as, %{binding: b, field: f}, _opts)` | single-entry map destructuring | Router `evaluate/6` clause matches `{:parent_as, m}` (with `is_map(m) and not is_struct(m)` guard) and a sibling `{op, {:parent_as, m}}` clause, both using `Enum.reduce` over `m`'s entries — each `{binding_name, field_name}` pair becomes a `{:parent_as, {pb, pf}}` tuple-IR dispatch, AND-merged across entries via `merge_dynamic/3`. No `Map.fetch`, no list destructuring, no single-entry assumption. |
| `resolve_datetime_wrapper` | `[{datetime_op, datetime_term}]` list match | Router `evaluate/6` clause matches `{:date, m}` / `{:datetime, m}` (with `is_map(m) and not is_struct(m)` guard) and uses `Enum.reduce` over `m`'s entries — each `{datetime_op, term}` pair re-enters `evaluate/6` as its own `{wrapper, {datetime_op, term}}` tuple-IR term, AND-merged across entries via `merge_dynamic/3`. No list destructuring, no single-entry assumption. |

No sub-module ever sees a map-form wrapper. The router walks every wrapper's inner map with `Enum.reduce` and re-emits one tuple-IR dispatch per entry — multi-entry maps fan out as conjunctions. No exact-shape matches, no single-entry assumptions, no `Map.fetch` against assumed keys.

---

## Change 5 — Bare-map `dispatch_expr` clause: single reduce

Not in the 4 stated problems but the same double-traversal pattern as Change 1.

**Before** (lines 203–211):
```elixir
defp dispatch_expr(source, selected_binding, key, negated, term, opts)
     when is_map(term) and not is_struct(term) do
  term
  |> Map.to_list()
  |> Enum.map(fn {inner_op, inner_value} ->
    dispatch_expr(source, selected_binding, key, negated, {inner_op, inner_value}, opts)
  end)
  |> Enum.reduce(nil, &merge_dynamic(&2, :and, &1))
end
```

**After**:
```elixir
defp dispatch_expr(source, selected_binding, key, negated, term, opts)
     when is_map(term) and not is_struct(term) do
  Enum.reduce(term, nil, fn {inner_op, inner_value}, acc ->
    dyn = dispatch_expr(source, selected_binding, key, negated, {inner_op, inner_value}, opts)
    merge_dynamic(acc, :and, dyn)
  end)
end
```

---

## Test changes

Remove these describe blocks from `test/ecto_shorts/dynamic_builders/postgres_test.exs` — `build_quantified_query/3` no longer exists in `postgres.ex`:

- `"build_quantified_query/3 when params is not a keyword list"`
- `"build_quantified_query/3 with a binary select spec"`
- `"build_quantified_query/3 with a map select spec"`
- `"build_quantified_query/3 with an unrecognized select spec type"`

Add integration tests in `test/ecto_shorts/common_filters/` that exercise the subquery spec path through `CommonFilters.convert_params_to_filter/3` with `{:all, [from: ..., select: ..., ...]}` payloads.

**RHS IR translation tests** — any `postgres_test.exs` describe block that asserted against `cast_value/2`, `build_rhs_entry/4`, `build_rhs_expr/3`, `resolve_datetime_wrapper/3`, or `resolve_datetime_node/3` as private-function contracts is removed. The behaviours these tests covered (arithmetic operands, `:parent_as` binding resolution, datetime wrappers, `:value` wrapping, `:field` reference translation) are exercised end-to-end through `DynamicBuilders.Postgres.build_dynamic/4` against the public filter grammar. New describe blocks covering the router's wrapper-normalization and Operand-normalization behaviour live in `postgres_test.exs`, because that is where the normalization code lives. Sub-module tests (`scalar_expr_test.exs`, `array_expr_test.exs`, `map_expr_test.exs`) assert against tuple IR inputs only — they do not exercise map-form wrappers, because sub-modules never receive them.

`cast_value/2` call-boundary tests are removed. The single `Types.cast` call in `evaluate_field/6` is exercised implicitly by every integration test that passes a raw value through `CommonFilters.convert_params_to_filter/3`.

---

## Change 6 — Single-pass walker; evaluator matches the aggregated tuple

### Traversal rule

The data structure is traversed **once**. No helper function walks the same nodes that the main walker has already touched (or will touch). The walker itself collapses single-entry containers into tuple chains, fans out multi-entry containers, and hands the final aggregated term to `evaluate/6` — all within one recursive descent.

### Walker — one function, one pass

**Traversal strategy: keyword list.** Maps are never traversed as maps. They are converted to keyword lists at the two positions where a map can appear (value slot, or inner of a tuple value slot) and re-entered. All descent, reduction, and fan-out happens against keyword lists. One strategy, one set of reduction clauses.

**Signature:** `(source, binding, key, negated, term, opts)` — the same shape as `evaluate/6` and `evaluate_field/6`, so no arg reshape ever happens across the routing pipeline. It also matches the sub-module callback tail `(binding, key, negated, term, opts)` with `source` prepended.

Each clause handles one shape at one node; control either normalizes (map → list), descends once (consuming one level of nesting), or reaches a leaf (hands off to `evaluate`). No node is visited twice.

```elixir
# Map in value slot — normalize to keyword list and re-enter.
defp walk(s, b, k, n, v, o) when is_map(v) and not is_struct(v) do
  walk(s, b, k, n, Map.to_list(v), o)
end

# Keyword list value — one dyn per entry, respecting :and/:or groups.
# Plain (non-keyword) list falls through as an equality operand.
defp walk(s, b, k, n, v, o) when is_list(v) do
  if Keyword.keyword?(v) and v !== [] do
    Enum.reduce(v, nil, fn entry, acc ->
      {merge_op, lifted} =
        case entry do
          {op, term} when op in [:and, :or] -> {op, term}
          {ck, child} -> {:and, {normalize_op(ck), child}}
        end

      dyn = walk(s, b, k, n, lifted, o)
      merge_dynamic(acc, merge_op, dyn)
    end)
  else
    evaluate(s, b, k, n, {:==, v}, o)
  end
end

# Tuple value — hand off intact. The walker does NOT descend into tuple
# inners; the evaluator pattern-matches tuple shapes and normalizes payloads
# locally where needed.
defp walk(s, b, k, n, {_, _} = v, o) do
  evaluate(s, b, k, n, v, o)
end

# Bare scalar value — wrap as equality.
defp walk(s, b, k, n, value, o) do
  evaluate(s, b, k, n, {:==, value}, o)
end
```

The walker handles **only** top-level field fan-out. Wrapper payloads (`:aggregate`, `:elements`) and Operand RHS trees reach the evaluator intact — descending into tuple inners would incorrectly fan out their payload keys. Short-op aliasing (`:eq` → `:==`, etc.) happens via `normalize_op/1` at the exact moment each level is lifted into a tuple.

### Evaluator — pattern-matches on the term slot

One function, one clause per meaning. Same `(source, binding, key, negated, term, opts)` signature as `walk/6` and `evaluate_field/6`. No container walking here — by the time a term reaches `evaluate/6`, every container has been collapsed or fanned out.

```elixir
defp evaluate(s, b, k, _n, {:not, value}, o), do: evaluate(s, b, k, :not, value, o)

defp evaluate(s, b, k, n, value, o) when k in @common_expr_operators,
  do: evaluate_field(s, b, k, n, value, o)

defp evaluate(s, b, k, n, {q, payload}, o) when q in @quantifier_operators,
  do: evaluate_field(s, b, k, n, {q, payload}, o)

defp evaluate(s, b, k, n, {t, v}, o) when t in @transform_ops do
  op = if t in [:lower, :downcase], do: :lower, else: :upper
  evaluate_field(s, b, k, n, {:==, {op, v}}, o)
end

defp evaluate(s, b, k, n, {agg, {cmp, v}}, o) when agg in @agg_fns,
  do: evaluate_field(s, b, k, n, {agg, {cmp, v}}, o)

defp evaluate(s, b, k, n, {:aggregate, params}, o), do: ... # wrapper body
defp evaluate(_s, b, k, n, {:elements, params}, o), do: ... # wrapper body

# {op, rhs_params} with map RHS — normalized to keyword list by the top clause.
defp evaluate(s, b, k, n, {op, rhs}, o)
     when is_map(rhs) and not is_struct(rhs), do: ...

# Plain {op, value}
defp evaluate(s, b, k, n, {op, v}, o), do: evaluate_field(s, b, k, n, {op, v}, o)

# Bare value already wrapped by the walker as {:==, value}
```

### Traversal proof

Input `[views: %{avg: %{gt: 10}}]`:

```
walk({:views, %{avg: %{gt: 10}}})           # outer map value
  → map normalizer → walk({:views, [avg: %{gt: 10}]})
    → keyword-list clause, reduce (1 entry)
      → walk({:views, {:avg, %{gt: 10}}})   # tuple value — handed off intact
        → evaluator: map normalizer → {:avg, [gt: 10]}
          → agg-shorthand keyword-list clause, reduce (1 entry)
            → evaluate_field({:views, {:avg, {:gt, 10}}})
```

Input `[views: %{gt: 5, lt: 10}]`:

```
walk({:views, %{gt: 5, lt: 10}})            # outer map value
  → map normalizer → walk({:views, [gt: 5, lt: 10]})
    → keyword-list clause, reduce (2 entries)
      → walk({:views, {:gt, 5}}) → evaluate # entry 1
      → walk({:views, {:lt, 10}}) → evaluate # entry 2
```

Input `[views: %{aggregate: %{fn: :avg, compare: :>, value: 5}}]`:

```
walk({:views, %{aggregate: ...}})           # outer map value
  → map normalizer → walk({:views, [aggregate: %{...}]])
    → keyword-list clause, reduce (1 entry)
      → walk({:views, {:aggregate, %{...}}})
        → tuple-value clause — handed off intact
          → evaluator :aggregate clause → Keyword.fetch!/2 on normalized payload
```

Input `[views: %{gt: %{add: [%{field: "base"}, %{value: 5}]}}]` (Operand RHS):

```
walk({:views, %{gt: %{add: [...]}}})        # outer map value
  → map normalizer → walk({:views, [gt: %{add: [...]}]])
    → keyword-list clause, reduce (1 entry)
      → walk({:views, {:gt, %{add: [...]}}})
        → tuple-value clause — handed off
          → evaluator top normalizer → {:gt, [add: [...]]}
          → evaluate_field({:views, {:gt, [add: [...]]}})
          → ScalarExpr receives one-entry keyword-list Operand
```

### What this replaces

Every current `dispatch_expr` clause — quantifier, short-op alias, transform, agg shorthand, aggregate/elements wrappers, common-expr keys, map-RHS walk, plain-op — becomes one `evaluate/6` clause. The walker is 4 clauses (top-level fan-out only); the evaluator is larger because it owns every wrapper-normalization step (datetime, `parent_as`, Operand RHS, transform, aggregate shorthand, elements, quantifier) in addition to plain shape dispatch. `Map.to_list` appears only at fan-out boundaries — never as a single-pair extraction. Inner maps inside wrappers (datetime, `parent_as`) are walked with `Enum.reduce`, one tuple-IR dispatch per entry, AND-merged across entries via `merge_dynamic/3`. No `[{k, v}]` exact-shape matches, no `Map.fetch!` against assumed keys, no single-entry assumptions. Wrapper payloads and RHS Operand trees are fully normalized to **tuple IR** before reaching any sub-module. Sub-modules see only tuple IR.

---

## Change 7 — Replace `:arithmetic` wrapper with the Operand RHS shape

The `:arithmetic` wrapper is deleted. Arithmetic on the RHS of a comparison uses a recursive `Operand` shape — a single-key map grammar with 13 keys. This is the only supported form on v3.0.0. No translator, no deprecation, no bridge.

### Grammar

```
Operand = %{field: String | Atom}
        | %{value: Scalar}
        | %{add | subtract | multiply | divide: [Operand]}   # variadic, >= 2
        | %{power | mod: [Operand, Operand]}                   # exactly 2
        | %{abs | round | floor | ceil | sqrt: Operand}        # single operand
```

### Shape examples

Basic comparison (literal on RHS):

```elixir
%{views: %{gt: 5}}
%{views: %{gt: %{value: 5}}}
```

Field reference:

```elixir
%{score: %{gt: %{field: "base"}}}
```

Arithmetic — `views > base + 5`:

```elixir
%{views: %{gt: %{add: [%{field: "base"}, %{value: 5}]}}}
```

Nested — `views > 1 + (2 * (4 - 1))`:

```elixir
%{views: %{gt: %{add: [
  %{value: 1},
  %{multiply: [
    %{value: 2},
    %{subtract: [%{value: 4}, %{value: 1}]}
  ]}
]}}}
```

Unary math — `views > |delta|`:

```elixir
%{views: %{gt: %{abs: %{field: "delta"}}}}
```

Binary math — `views > base ^ 2`, `views > count % 10`:

```elixir
%{views: %{gt: %{power: [%{field: "base"}, %{value: 2}]}}}
%{views: %{gt: %{mod: [%{field: "count"}, %{value: 10}]}}}
```

### Removed

Entry rejects `:arithmetic`:

```elixir
# GONE — no translator, no deprecation warning
%{score: %{arithmetic: %{compare: :>, add: %{field: :base, value: 5}}}}
```

Replaced by:

```elixir
%{score: %{gt: %{add: [%{field: "base"}, %{value: 5}]}}}
```

The `:arithmetic` evaluator clause in `postgres.ex` is deleted. Every test asserting the old `%{arithmetic: ...}` shape is rewritten against the Operand grammar.

### Bare scalars on RHS and inside operand lists

A non-map/non-list RHS is treated as `%{value: v}`. Inside an operator-node operand list, bare scalars are accepted alongside Operand maps — each sub-module lifts them to `%{value: v}` when translating.

```elixir
%{views: %{gt: 5}}                               # == %{views: %{gt: %{value: 5}}}
%{views: %{gt: -5}}                              # literal negative, unchanged
%{views: %{gt: %{add: [%{field: "base"}, 5]}}}   # 5 lifted to %{value: 5}
```

No `negate` operator — negative literals pass through as-is. Grammar stays at 13 keys.

### Operand-list arity — skip and warn

Wrong arity never raises. The owning sub-module (primarily `ScalarExpr`) emits `nil`, logs `EctoShorts.Logger.warning` with `@logger_prefix`, and continues. `merge_dynamic` already tolerates `nil`.

| Shape | Outcome |
|---|---|
| `%{add: []}` / `%{subtract: []}` / `%{multiply: []}` / `%{divide: []}` | skip + warn |
| `%{add: [x]}` / etc. (variadic given 1 operand) | skip + warn (not identity) |
| `%{power: [x]}` / `%{mod: [x, y, z]}` (binary given wrong arity) | skip + warn |
| `%{abs: []}` / `%{abs: [x, y]}` (unary given a list) | skip + warn |

Canonical warning message:

```
"Operand `<op>` requires <n> operand(s), got: <inspect(value)>; skipping"
```

### Field-name resolution

`field_name_to_atom/3` stays in `postgres.ex` and remains **private** (`defp`). The router's Operand normalizer calls it during Operand-tree traversal to convert every `%{field: binary}` node to `{:field, :atom}`. By the time tuple IR reaches `ScalarExpr`, every `:field` leaf carries an atom. `ScalarExpr` does not call `field_name_to_atom/3`, does not import `Postgres`, and does not know about binary field names.

### Handoff contract

The router owns all Operand-tree walking and emits **tuple IR** to `ScalarExpr.dynamic_expr/5`. The normalization rules:

| Shape seen by `evaluate/6` | Tuple IR emitted to `ScalarExpr` |
|---|---|
| `{op, %{field: "base"}}` | `{op, {:field, :base}}` |
| `{op, %{value: 5}}` | `{op, {:value, 5}}` |
| `{op, %{add: [%{field: "x"}, %{value: 1}]}}` | `{op, {:add, [{:field, :x}, {:value, 1}]}}` |
| `{op, %{abs: %{field: :y}}}` | `{op, {:abs, {:field, :y}}}` |
| `{op, %{add: [%{field: "x"}, 5]}}` (bare scalar) | `{op, {:add, [{:field, :x}, {:value, 5}]}}` (lifted in router) |
| `{op, %{add: []}}` (arity violation) | `nil` emitted directly (warn + skip in router) |
| `{op, 5}` (no Operand) | `{op, 5}` (unchanged — not an Operand shape) |

**Router owns:**
- Operand tree traversal (recursive map-to-tuple conversion)
- Field-name resolution (binary → atom via `field_name_to_atom/3`)
- Arity validation — skip + warn, never raise; router emits `nil` directly and does not invoke `ScalarExpr`
- Bare-scalar lifting inside operand lists to `{:value, v}`

**`ScalarExpr` owns (and only):**
- Pattern-matching tuple IR on `dispatch_expr(binding, key, {op, tuple})` clauses
- Code generation — emitting the `Ecto.Query.dynamic_expr/0` for each tuple shape
- Recursive tuple-to-SQL emission for nested Operand tuples (e.g. walking `{:add, [tuple, tuple]}` to produce `^a + ^b` via a pure tuple-IR walker with no normalization, no field-name resolution, no arity validation)

Tuple-to-SQL emission is *not* IR translation: the input and output are both already-canonical forms (tuple IR in, Ecto dynamic out). The prohibition on RHS IR translation in sub-modules is about converting one input form into another form (map → tuple, binary → atom, arity-validated → arity-checked); emitting SQL from a validated tuple is code generation and stays in the sub-module where the SQL is written.

### Test impact

- Every describe block in `test/ecto_shorts/dynamic_builders/postgres_test.exs` asserting the `%{arithmetic: ...}` wrapper is rewritten against the Operand grammar. These describe blocks stay in `postgres_test.exs` because Operand-to-tuple normalization lives in the router — `postgres.ex` is where the behaviour is implemented and tested.
- New describe blocks in `postgres_test.exs` cover: variadic arity (`add`/`subtract`/`multiply`/`divide`), binary arity (`power`/`mod`), unary arity (`abs`/`round`/`floor`/`ceil`/`sqrt`), nested Operand trees, bare-scalar lifting, binary field-name resolution, and every "skip + warn" arity case — end-to-end through `DynamicBuilders.Postgres.build_dynamic/4`.
- `scalar_expr_test.exs` gains describe blocks for tuple-IR arithmetic dispatch: `{op, {:field, atom}}`, `{op, {:value, v}}`, `{op, {:add, [tuple, ...]}}`, etc. These tests pass pre-normalized tuple IR directly to `ScalarExpr.dynamic_expr/5` and assert the generated SQL. They do *not* exercise map-form input — sub-modules never receive it.

---

## Projected final state of `lib/ecto_shorts/dynamic_builders/postgres.ex`

```elixir
defmodule EctoShorts.DynamicBuilders.Postgres do
  @moduledoc """
  Build Postgres-specific dynamic filter expressions.
  ...
  """

  import Ecto.Query, only: [dynamic: 1]

  alias EctoShorts.{
    CommonSchema,
    DynamicBuilders.Postgres.ArrayExpr,
    DynamicBuilders.Postgres.CommonExpr,
    DynamicBuilders.Postgres.MapExpr,
    DynamicBuilders.Postgres.ScalarExpr,
    Types
  }

  @behaviour EctoShorts.DynamicBuilder

  @logger_prefix "EctoShorts.DynamicBuilders.Postgres"

  # ── Module attributes ────────────────────────────────────────────────
  # Operator and wrapper-key vocabularies. Used as guard-set membership
  # checks throughout the evaluator. Sub-modules don't reference these;
  # they receive normalized tuple IR in which all wrapper names have
  # already been canonicalized.

  @quantifier_operators [:all, :any]
  @common_expr_operators CommonExpr.operators()
  @short_ops [:eq, :ne, :gt, :gte, :lt, :lte]
  @comparison_operators [:==, :!=, :>, :>=, :<, :<=]
  @agg_fns [:avg, :sum, :max, :min, :count]
  @transform_ops [:lower, :upper, :downcase, :upcase]
  @datetime_wrappers [:date, :datetime]

  # Operand grammar keys (Change 7). Single-key Operand maps in a
  # comparison RHS use one of these keys to identify the operand kind.
  # The router owns Operand-tree normalization; sub-modules (ScalarExpr)
  # receive fully-normalized tuple IR.
  @operand_leaf_keys [:field, :value]
  @operand_variadic_keys [:add, :subtract, :multiply, :divide]
  @operand_binary_keys [:power, :mod]
  @operand_unary_keys [:abs, :round, :floor, :ceil, :sqrt]
  @operand_keys @operand_leaf_keys ++
                  @operand_variadic_keys ++ @operand_binary_keys ++ @operand_unary_keys

  # ── build_dynamic/4 ──────────────────────────────────────────────────
  # Public entry point. Implements EctoShorts.DynamicBuilder for Postgres.
  # Returns a dynamic expression for the given filter entry, or nil when
  # every child predicate skipped.
  #
  # build_dynamic(Post, {:as, nil}, {:views, 5}, [])
  #   ⇒ dynamic([p], p.views == 5)
  #
  # build_dynamic(Post, {:as, nil}, {:any, [published: true, archived: false]}, [])
  #   ⇒ dynamic([p], p.published == true or p.archived == false)
  #
  # build_dynamic(Post, {:as, nil}, {:all, [views: 5, archived: false]}, [])
  #   ⇒ dynamic([p], p.views == 5 and p.archived == false)
  #
  # build_dynamic({"posts", nil}, {:as, nil}, {:tags, ["a"]},
  #               field_types: [tags: {:array, :string}])
  #   ⇒ dynamic([p], "a" in p.tags)
  #
  # build_dynamic(Post, {:at, 2}, {:title, "x"}, [])
  #   ⇒ dynamic([_, _, p], p.title == "x")
  #
  # build_dynamic(Post, {:as, :author}, {:name, "Alice"}, [])
  #   ⇒ dynamic([author: a], a.name == "Alice")
  #
  # build_dynamic(Post, {:as, nil},
  #               {:score, %{gt: %{add: [%{field: :base}, %{value: 5}]}}}, [])
  #   ⇒ dynamic([p], p.score > p.base + 5)
  #
  # build_dynamic(Post, {:as, nil}, {:title, %{}}, [])    # empty wrapper, no children
  #   ⇒ nil
  @impl true
  @spec build_dynamic(term(), {:as, nil | atom()} | {:at, pos_integer()}, term(), keyword()) ::
          Ecto.Query.dynamic_expr() | nil
  def build_dynamic(source, selected_binding, args, opts \\ [])

  # Quantifier head — top-level :all / :any group. Reduces over `params`,
  # building one child dyn per entry, merging via the requested
  # quantifier (:and for :all, :or for :any). The outer merge_dynamic/3
  # call wraps the aggregate to keep parenthesization explicit when the
  # caller composes this with other dyns.
  def build_dynamic(source, selected_binding, {quantifier_op, params}, opts)
      when quantifier_op in @quantifier_operators do
    expr =
      Enum.reduce(params, nil, fn {key, term}, acc ->
        dyn = build_dynamic(source, selected_binding, {key, term}, opts)
        merge_dynamic(acc, quantifier_op, dyn)
      end)

    merge_dynamic(nil, :and, expr)
  end

  # Ordinary entry head — single {key, term}. Hands off to walk/6 with
  # negated=nil; walk/6 handles map / kwlist / tuple / scalar value shapes.
  def build_dynamic(source, selected_binding, {key, params}, opts) do
    dyn = walk(source, selected_binding, key, nil, params, opts)
    merge_dynamic(nil, :and, dyn)
  end

  # ── walk/6 ───────────────────────────────────────────────────────────
  # Single-pass, top-level fan-out walker. Routes the value slot of a
  # {key, value} entry into evaluate/6, fanning out maps and keyword
  # lists into per-entry sub-calls. Returns a dynamic expression or nil.
  #
  # The walker does NOT descend into tuple inners: wrapper payloads
  # (:aggregate, :elements) and Operand RHS trees reach the evaluator
  # intact, where the owning clause or sub-module handles them. Short-op
  # aliases (:eq → :==, etc.) are normalized inline at each entry lift
  # via normalize_op/1.

  # Map clause — convert to keyword list and re-enter.
  #
  # walk(Post, {:as, nil}, :views, nil, %{gt: 5, lt: 10}, [])
  #   ⇒ walk(Post, {:as, nil}, :views, nil, [gt: 5, lt: 10], [])
  #   ⇒ dynamic([p], p.views > 5 and p.views < 10)
  defp walk(source, binding, key, negated, v, opts)
       when is_map(v) and not is_struct(v) do
    walk(source, binding, key, negated, Map.to_list(v), opts)
  end

  # List clause. Non-empty keyword lists fan out: one dyn per entry,
  # AND-merged by default. {:and, term} / {:or, term} entries lift
  # their inner term into a sub-walk merged with the parent acc using
  # the requested operator. Non-keyword lists fall through as a single
  # equality (membership) operand.
  #
  # walk(Post, {:as, nil}, :views, nil, [gt: 5, lt: 10], [])
  #   ⇒ dynamic([p], p.views > 5 and p.views < 10)
  #
  # walk(Post, {:as, nil}, :views, nil, [or: [gt: 100], lt: 5], [])
  #   ⇒ dynamic([p], p.views > 100 or p.views < 5)
  #
  # walk(Post, {:as, nil}, :tags, nil, ["red", "blue"], [])
  #   # non-keyword list → equality with the list as RHS
  #   ⇒ evaluate(... {:==, ["red", "blue"]}, ...)
  defp walk(source, binding, key, negated, v, opts) when is_list(v) do
    if Keyword.keyword?(v) and v !== [] do
      Enum.reduce(v, nil, fn entry, acc ->
        {merge_op, lifted} =
          case entry do
            {op, term} when op in [:and, :or] -> {op, term}
            {k, child} -> {:and, {normalize_op(k), child}}
          end

        dyn = walk(source, binding, key, negated, lifted, opts)
        merge_dynamic(acc, merge_op, dyn)
      end)
    else
      evaluate(source, binding, key, negated, {:==, v}, opts)
    end
  end

  # Tuple clause — hand to evaluate/6 unchanged.
  #
  # walk(Post, {:as, nil}, :views, nil, {:>, 5}, [])
  #   ⇒ evaluate(Post, {:as, nil}, :views, nil, {:>, 5}, [])
  #   ⇒ dynamic([p], p.views > 5)
  defp walk(source, binding, key, negated, {_, _} = v, opts) do
    evaluate(source, binding, key, negated, v, opts)
  end

  # Bare scalar — wrap as equality.
  #
  # walk(Post, {:as, nil}, :views, nil, 5, [])
  #   ⇒ evaluate(Post, {:as, nil}, :views, nil, {:==, 5}, [])
  #   ⇒ dynamic([p], p.views == 5)
  defp walk(source, binding, key, negated, value, opts) do
    evaluate(source, binding, key, negated, {:==, value}, opts)
  end

  # ── normalize_op/1 ───────────────────────────────────────────────────
  # Short-op alias resolver, used by the kwlist fan-out in walk/6 to
  # canonicalize operator keys at lift time.
  #
  # normalize_op(:eq)  ⇒ :==
  # normalize_op(:ne)  ⇒ :!=
  # normalize_op(:gt)  ⇒ :>
  # normalize_op(:gte) ⇒ :>=
  # normalize_op(:lt)  ⇒ :<
  # normalize_op(:lte) ⇒ :<=
  # normalize_op(:in)  ⇒ :in    # not a short-op, passes through
  # normalize_op(:foo) ⇒ :foo   # unknown key, passes through
  defp normalize_op(op) when op in @short_ops, do: op_alias(op)
  defp normalize_op(op), do: op

  # ── evaluate/6 ───────────────────────────────────────────────────────
  # The router and normalizer. One clause per public-API meaning. Owns
  # ALL map-form wrapper normalization in this module: every map-form
  # wrapper a caller can express is reduced to tuple IR here before any
  # sub-module is invoked. Sub-modules receive only tuple IR — never a
  # map, never a keyword list of Operand shells, never a binary field
  # name.
  #
  # Returns a dynamic expression or nil. Types.cast is called once per
  # leaf in evaluate_field/6 — after all normalization is complete.

  # Negation lift. Re-enters with negated=:not so the inner shape's
  # clause carries negation forward.
  #
  # evaluate(Post, {:as, nil}, :views, nil, {:not, {:>, 5}}, [])
  #   ⇒ evaluate(Post, {:as, nil}, :views, :not, {:>, 5}, [])
  #   ⇒ dynamic([p], not (p.views > 5))
  defp evaluate(source, binding, key, _negated, {:not, value}, opts) do
    evaluate(source, binding, key, :not, value, opts)
  end

  # Datetime wrapper with map or keyword-list inner — reduce, one dyn per
  # entry. Map and kwlist iterate as {k, v} pairs in Enum.reduce, so a
  # single clause handles both. Non-kwlist lists return nil rather than
  # falling through to the {datetime_op, term} destructure.
  #
  # evaluate(Post, {:as, nil}, :inserted_at, nil,
  #          {:date, %{add: %{days: 7}, before: ~D[2026-01-01]}}, [])
  #   # reduces 2 entries, each re-entering as {:date, {op, term}}:
  #   #   {:date, {:add, %{days: 7}}}
  #   #   {:date, {:before, ~D[2026-01-01]}}
  #   ⇒ dynamic([p],
  #       fragment("? + INTERVAL '7 days'", p.inserted_at) and
  #       p.inserted_at < ~D[2026-01-01])
  #
  # evaluate(Post, {:as, nil}, :inserted_at, nil,
  #          {:date, [add: [days: 7], before: ~D[2026-01-01]]}, [])
  #   # kwlist inner — same reduce, same dispatches
  #   ⇒ dynamic([p],
  #       fragment("? + INTERVAL '7 days'", p.inserted_at) and
  #       p.inserted_at < ~D[2026-01-01])
  #
  # evaluate(Post, {:as, nil}, :inserted_at, nil, {:date, %{}}, [])
  #   ⇒ nil    # empty inner, reduce yields nil
  #
  # evaluate(Post, {:as, nil}, :inserted_at, nil, {:date, [1, 2, 3]}, [])
  #   ⇒ nil    # non-kwlist list, skipped
  defp evaluate(source, binding, key, negated, {wrapper, inner}, opts)
       when wrapper in @datetime_wrappers and
              ((is_map(inner) and not is_struct(inner)) or is_list(inner)) do
    if is_list(inner) and not Keyword.keyword?(inner) do
      nil
    else
      Enum.reduce(inner, nil, fn {datetime_op, term}, acc ->
        dyn = evaluate(source, binding, key, negated, {wrapper, {datetime_op, term}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    end
  end

  # parent_as wrapper with map or keyword-list inner. Each entry
  # {pb, pf} of the inner IS a parent_as reference: key = binding name,
  # value = field name. Multi-entry maps/kwlists fan out as a conjunction.
  #
  # evaluate(Comment, {:as, nil}, :post_id, nil, {:parent_as, %{post: :id}}, [])
  #   ⇒ evaluate_field(... {:parent_as, {:post, :id}})
  #   ⇒ dynamic([c], c.post_id == parent_as(:post).id)
  #
  # evaluate(Comment, {:as, nil}, :post_id, nil, {:parent_as, [post: :id]}, [])
  #   # kwlist inner — same reduce, same dispatch
  #   ⇒ dynamic([c], c.post_id == parent_as(:post).id)
  #
  # evaluate(Comment, {:as, nil}, :post_id, nil, {:parent_as, [1, 2, 3]}, [])
  #   ⇒ nil    # non-kwlist list, skipped
  defp evaluate(source, binding, key, negated, {:parent_as, inner}, opts)
       when (is_map(inner) and not is_struct(inner)) or is_list(inner) do
    if is_list(inner) and not Keyword.keyword?(inner) do
      nil
    else
      Enum.reduce(inner, nil, fn {pb, pf}, acc ->
        dyn = evaluate_field(source, binding, key, negated, {:parent_as, {pb, pf}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    end
  end

  # parent_as wrapper nested under a comparison op. Map or keyword-list
  # inner accepted, same as the bare {:parent_as, inner} clause.
  #
  # evaluate(Comment, {:as, nil}, :views, nil,
  #          {:>, {:parent_as, %{post: :views}}}, [])
  #   ⇒ evaluate_field(... {:>, {:parent_as, {:post, :views}}})
  #   ⇒ dynamic([c], c.views > parent_as(:post).views)
  #
  # evaluate(Comment, {:as, nil}, :views, nil,
  #          {:>, {:parent_as, [post: :views]}}, [])
  #   ⇒ dynamic([c], c.views > parent_as(:post).views)
  defp evaluate(source, binding, key, negated, {op, {:parent_as, inner}}, opts)
       when (is_map(inner) and not is_struct(inner)) or is_list(inner) do
    if is_list(inner) and not Keyword.keyword?(inner) do
      nil
    else
      Enum.reduce(inner, nil, fn {pb, pf}, acc ->
        dyn = evaluate_field(source, binding, key, negated, {op, {:parent_as, {pb, pf}}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    end
  end

  # Operand RHS — comparison op with a map or keyword-list RHS that may
  # be an Operand. Routes to the Operand normalizer when rhs is a
  # single-entry map/kwlist whose key is in @operand_keys; otherwise
  # falls through to a plain literal RHS or kwlist re-entry.
  #
  # evaluate(Post, {:as, nil}, :score, nil,
  #          {:>, %{add: [%{field: :base}, %{value: 5}]}}, [])
  #   ⇒ evaluate_field(... {:>, {:add, [{:field, :base}, {:value, 5}]}})
  #   ⇒ dynamic([p], p.score > p.base + 5)
  #
  # evaluate(Post, {:as, nil}, :score, nil,
  #          {:>, [add: [%{field: :base}, %{value: 5}]]}, [])
  #   # kwlist Operand — same dispatch
  #   ⇒ dynamic([p], p.score > p.base + 5)
  #
  # evaluate(Post, {:as, nil}, :score, nil, {:>, %{add: []}}, [])
  #   # arity violation in normalize_operand → :error
  #   ⇒ nil
  #
  # evaluate(Post, {:as, nil}, :tags, nil, {:==, [1, 2, 3]}, [])
  #   # plain list (not a kwlist) — literal RHS, passed to evaluate_field
  #   ⇒ evaluate_field(... {:==, [1, 2, 3]})
  defp evaluate(source, binding, key, negated, {op, rhs}, opts)
       when op in @comparison_operators and
              ((is_map(rhs) and not is_struct(rhs)) or is_list(rhs)) do
    cond do
      is_list(rhs) and not Keyword.keyword?(rhs) ->
        evaluate_field(source, binding, key, negated, {op, rhs}, opts)

      operand_shape?(rhs) ->
        case normalize_operand(source, rhs, opts) do
          {:ok, tuple_ir} ->
            evaluate_field(source, binding, key, negated, {op, tuple_ir}, opts)

          :error ->
            nil
        end

      is_map(rhs) ->
        evaluate(source, binding, key, negated, {op, Map.to_list(rhs)}, opts)

      true ->
        evaluate_field(source, binding, key, negated, {op, rhs}, opts)
    end
  end

  # Generic map payload — any non-Operand, non-wrapper inner map under
  # any operator. Convert to keyword list and re-enter; downstream
  # clauses never see a map payload.
  #
  # evaluate(Post, {:as, nil}, :score, nil, {:aggregate, %{fn: :avg, compare: :>, value: 50}}, [])
  #   ⇒ evaluate(Post, {:as, nil}, :score, nil,
  #              {:aggregate, [fn: :avg, compare: :>, value: 50]}, [])
  defp evaluate(source, binding, key, negated, {op, params}, opts)
       when is_map(params) and not is_struct(params) do
    evaluate(source, binding, key, negated, {op, Map.to_list(params)}, opts)
  end

  # Common-expression key — the KEY is the operator (e.g. :before,
  # :after, :exists, :since, :until). Hands to evaluate_field/6 unchanged;
  # evaluate_field's first clause routes to CommonExpr.
  #
  # evaluate(Post, {:as, nil}, :before, nil, ~D[2026-01-01], [])
  #   ⇒ evaluate_field(... :before, nil, ~D[2026-01-01], ...)
  #   ⇒ CommonExpr.dynamic_expr({:as, nil}, :before, nil, ~D[2026-01-01], [])
  #   ⇒ dynamic([p], p.inserted_at < ~D[2026-01-01])
  defp evaluate(source, binding, key, negated, value, opts)
       when key in @common_expr_operators do
    evaluate_field(source, binding, key, negated, value, opts)
  end

  # Quantified comparison with list payload. A non-empty kwlist fans out
  # as one dyn per (op, v) pair, AND-merged; otherwise the payload is
  # dispatched whole to evaluate_field/6.
  #
  # evaluate(Post, {:as, nil}, :value, nil, {:any, [eq: 1, gt: 100]}, [])
  #   # kwlist → 2 dispatches:
  #   #   evaluate_field(... {:any, {:==, 1}})
  #   #   evaluate_field(... {:any, {:>, 100}})
  #   ⇒ dynamic([p], p.value == any(...) and p.value > any(...))
  #
  # evaluate(Post, {:as, nil}, :value, nil, {:any, sub_query}, [])
  #   ⇒ evaluate_field(... {:any, sub_query})    # not a kwlist → passed whole
  defp evaluate(source, binding, key, negated, {quantifier, payload}, opts)
       when quantifier in @quantifier_operators and is_list(payload) do
    if Keyword.keyword?(payload) and payload !== [] do
      Enum.reduce(payload, nil, fn {op, v}, acc ->
        canonical_op = if op in @short_ops, do: op_alias(op), else: op
        dyn = evaluate_field(source, binding, key, negated, {quantifier, {canonical_op, v}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    else
      evaluate_field(source, binding, key, negated, {quantifier, payload}, opts)
    end
  end

  # Quantified comparison with non-list payload — single {op, v} tuple
  # or a pre-built Ecto.Query. Canonicalizes short-op aliases inline.
  #
  # evaluate(Post, {:as, nil}, :value, nil, {:any, {:eq, 1}}, [])
  #   ⇒ evaluate_field(... {:any, {:==, 1}})
  #
  # evaluate(Post, {:as, nil}, :value, nil, {:all, %Ecto.SubQuery{}}, [])
  #   ⇒ evaluate_field(... {:all, %Ecto.SubQuery{}})
  defp evaluate(source, binding, key, negated, {quantifier, payload}, opts)
       when quantifier in @quantifier_operators do
    canonical_payload =
      case payload do
        {op, v} when op in @short_ops -> {op_alias(op), v}
        other -> other
      end

    evaluate_field(source, binding, key, negated, {quantifier, canonical_payload}, opts)
  end

  # Transform wrapper. Folds :downcase / :upcase aliases into :lower /
  # :upper and emits {:==, {:lower|:upper, v}}, which ScalarExpr handles
  # via its string-transform family.
  #
  # evaluate(Post, {:as, nil}, :name, nil, {:downcase, "alice"}, [])
  #   ⇒ evaluate_field(... {:==, {:lower, "alice"}})
  #   ⇒ dynamic([p], fragment("LOWER(?)", p.name) == "alice")
  #
  # evaluate(Post, {:as, nil}, :name, nil, {:upcase, "ALICE"}, [])
  #   ⇒ evaluate_field(... {:==, {:upper, "ALICE"}})
  defp evaluate(source, binding, key, negated, {transform, v}, opts)
       when transform in @transform_ops do
    op = if transform in [:lower, :downcase], do: :lower, else: :upper
    evaluate_field(source, binding, key, negated, {:==, {op, v}}, opts)
  end

  # Aggregate shorthand — kwlist payload. agg_fn is one of @agg_fns
  # (:avg, :sum, :max, :min, :count). Each kwlist entry is a
  # {compare_op, value} pair; one dyn per pair, AND-merged.
  #
  # evaluate(Post, {:as, nil}, :score, nil, {:avg, [gt: 50, lt: 100]}, [])
  #   ⇒ AND-merge of:
  #       evaluate_field(... {:avg, {:>, 50}})
  #       evaluate_field(... {:avg, {:<, 100}})
  #   ⇒ dynamic([p], avg(p.score) > 50 and avg(p.score) < 100)
  defp evaluate(source, binding, key, negated, {agg_fn, params}, opts)
       when agg_fn in @agg_fns and is_list(params) do
    if Keyword.keyword?(params) and params !== [] do
      Enum.reduce(params, nil, fn {compare_op, v}, acc ->
        dyn = evaluate_field(source, binding, key, negated, {agg_fn, {compare_op, v}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    else
      evaluate_field(source, binding, key, negated, {agg_fn, params}, opts)
    end
  end

  # Aggregate shorthand — single {compare_op, v} tuple.
  #
  # evaluate(Post, {:as, nil}, :score, nil, {:avg, {:>, 50}}, [])
  #   ⇒ evaluate_field(... {:avg, {:>, 50}})
  #   ⇒ dynamic([p], avg(p.score) > 50)
  defp evaluate(source, binding, key, negated, {agg_fn, {compare_op, v}}, opts)
       when agg_fn in @agg_fns do
    evaluate_field(source, binding, key, negated, {agg_fn, {compare_op, v}}, opts)
  end

  # Aggregate wrapper — explicit %{aggregate: %{fn:, compare:, value:}}
  # shape, normalized to a kwlist by the generic map clause above.
  #
  # evaluate(Post, {:as, nil}, :score, nil,
  #          {:aggregate, [fn: :avg, compare: :>, value: 50]}, [])
  #   ⇒ evaluate_field(... {:avg, {:>, 50}})
  #   ⇒ dynamic([p], avg(p.score) > 50)
  defp evaluate(source, binding, key, negated, {:aggregate, params}, opts)
       when is_list(params) do
    agg_fn = Keyword.fetch!(params, :fn)
    compare_op = Keyword.fetch!(params, :compare)
    value = Keyword.fetch!(params, :value)
    evaluate_field(source, binding, key, negated, {agg_fn, {compare_op, value}}, opts)
  end

  # Elements wrapper — kwlist payload. Forces array routing in
  # evaluate_field/6 regardless of field type. Each kwlist entry re-
  # enters evaluate/6 as {:elements, {op, value}} so every pair gets
  # AND-merged through the same head match.
  #
  # evaluate({"posts", nil}, {:as, nil}, :tags, nil,
  #          {:elements, [in: ["a", "b"], not: %{eq: "c"}]}, [])
  #   ⇒ AND-merge of:
  #       evaluate(... {:elements, {:in, ["a", "b"]}}) → ArrayExpr
  #       evaluate(... {:elements, {:not, %{eq: "c"}}}) → ArrayExpr
  #
  # evaluate({"posts", nil}, {:as, nil}, :tags, nil, {:elements, [1, 2, 3]}, [])
  #   # not a kwlist → equality dispatch
  #   ⇒ evaluate_field(... {:elements, {:==, [1, 2, 3]}})
  defp evaluate(source, binding, key, negated, {:elements, params}, opts)
       when is_list(params) do
    if Keyword.keyword?(params) and params !== [] do
      Enum.reduce(params, nil, fn {op, value}, acc ->
        dyn = evaluate(source, binding, key, negated, {:elements, {op, value}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    else
      evaluate_field(source, binding, key, negated, {:elements, {:==, params}}, opts)
    end
  end

  # Elements wrapper with {op, inner} where inner is a map or kwlist —
  # fan out the inner, one dyn per pair, AND-merged. Non-kwlist lists
  # at this position are unsupported and return nil.
  #
  # evaluate(_, _, :tags, nil, {:elements, {:not, %{eq: "c", in: ["d"]}}}, _)
  #   ⇒ AND-merge of:
  #       evaluate(... {:elements, {:not, {:eq, "c"}}})
  #       evaluate(... {:elements, {:not, {:in, ["d"]}}})
  #
  # evaluate(_, _, :tags, nil, {:elements, {:not, [eq: "c", in: ["d"]]}}, _)
  #   # kwlist inner — same fan-out
  #   ⇒ AND-merge of two dispatches as above
  defp evaluate(source, binding, key, negated, {:elements, {op, inner}}, opts)
       when (is_map(inner) and not is_struct(inner)) or is_list(inner) do
    if is_list(inner) and not Keyword.keyword?(inner) do
      nil
    else
      Enum.reduce(inner, nil, fn {inner_op, v}, acc ->
        dyn = evaluate(source, binding, key, negated, {:elements, {op, {inner_op, v}}}, opts)
        merge_dynamic(acc, :and, dyn)
      end)
    end
  end

  # Elements wrapper with nil payload — equality against nil.
  #
  # evaluate(_, _, :tags, nil, {:elements, nil}, _)
  #   ⇒ evaluate_field(... {:elements, {:==, nil}})
  defp evaluate(source, binding, key, negated, {:elements, nil}, opts) do
    evaluate_field(source, binding, key, negated, {:elements, {:==, nil}}, opts)
  end

  # Elements wrapper with tuple payload.
  #
  # evaluate(_, _, :tags, nil, {:elements, {:in, ["a", "b"]}}, _)
  #   ⇒ evaluate_field(... {:elements, {:in, ["a", "b"]}})
  defp evaluate(source, binding, key, negated, {:elements, {_, _} = term}, opts) do
    evaluate_field(source, binding, key, negated, {:elements, term}, opts)
  end

  # Elements wrapper with bare value — treat as :in operand.
  #
  # evaluate(_, _, :tags, nil, {:elements, "a"}, _)
  #   ⇒ evaluate_field(... {:elements, {:in, "a"}})
  defp evaluate(source, binding, key, negated, {:elements, term}, opts) do
    evaluate_field(source, binding, key, negated, {:elements, {:in, term}}, opts)
  end

  # Plain {op, value} — fully tuple-IR by the time this clause fires.
  # Sub-modules receive only tuple IR.
  #
  # evaluate(Post, {:as, nil}, :views, nil, {:>, 5}, [])
  #   ⇒ evaluate_field(... {:>, 5})
  #   ⇒ dynamic([p], p.views > 5)
  defp evaluate(source, binding, key, negated, {op, v}, opts) do
    evaluate_field(source, binding, key, negated, {op, v}, opts)
  end

  # Bare scalar or non-keyword list — equality.
  #
  # evaluate(Post, {:as, nil}, :views, nil, 5, [])
  #   ⇒ evaluate_field(... {:==, 5})
  #   ⇒ dynamic([p], p.views == 5)
  defp evaluate(source, binding, key, negated, value, opts) do
    evaluate_field(source, binding, key, negated, {:==, value}, opts)
  end

  # ── evaluate_field/6 ─────────────────────────────────────────────────
  # Field-level router. Single Types.cast call site in this module. By
  # the time a term reaches evaluate_field/6, every wrapper has been
  # normalized to tuple IR by evaluate/6. Every sub-module dispatch
  # (CommonExpr, ScalarExpr, ArrayExpr, MapExpr) lives in this function.

  # Common-expr key dispatch. KEY is the operator; value passes through.
  #
  # evaluate_field(Post, {:as, nil}, :before, nil, ~D[2026-01-01], [])
  #   ⇒ CommonExpr.dynamic_expr({:as, nil}, :before, nil, ~D[2026-01-01], [])
  #   ⇒ dynamic([p], p.inserted_at < ~D[2026-01-01])
  defp evaluate_field(_source, binding, key, negated, value, opts)
       when key in @common_expr_operators do
    CommonExpr.dynamic_expr(binding, key, negated, value, opts)
  end

  # Elements-forced array dispatch. The {:elements, …} wrapper is the
  # explicit routing signal carried on the term itself; no opts flag,
  # no hidden state. Array inner-type casting is not performed here;
  # inputs are already tuple IR.
  #
  # evaluate_field(_, {:as, nil}, :tags, nil, {:elements, {:in, ["a", "b"]}}, [])
  #   ⇒ ArrayExpr.dynamic_expr({:as, nil}, :tags, nil, {:in, ["a", "b"]}, [])
  #   ⇒ dynamic([p], p.tags && ["a", "b"])
  defp evaluate_field(_source, binding, key, negated, {:elements, {_, _} = inner}, opts) do
    ArrayExpr.dynamic_expr(binding, key, negated, inner, opts)
  end

  # Generic field dispatch. Resolves field type, casts the raw value
  # once, and routes to MapExpr / ArrayExpr / ScalarExpr based on type.
  # Schema fields not declared on the schema produce a warning and skip.
  #
  # evaluate_field(Post, {:as, nil}, :views, nil, {:>, 5}, [])
  #   # Post.__schema__(:type, :views) = :integer → ScalarExpr
  #   ⇒ ScalarExpr.dynamic_expr({:as, nil}, :views, nil, {:>, 5}, [])
  #   ⇒ dynamic([p], p.views > 5)
  #
  # evaluate_field(Post, {:as, nil}, :metadata, nil, {:==, %{a: 1}}, [])
  #   # Post.__schema__(:type, :metadata) = :map → MapExpr
  #   ⇒ MapExpr.dynamic_expr({:as, nil}, :metadata, nil, {:==, %{a: 1}}, [])
  #
  # evaluate_field(Post, {:as, nil}, :tags, nil, {:in, ["a"]}, [])
  #   # Post.__schema__(:type, :tags) = {:array, :string} → ArrayExpr
  #   ⇒ ArrayExpr.dynamic_expr({:as, nil}, :tags, nil, {:in, ["a"]}, [])
  #
  # evaluate_field(Post, {:as, nil}, :nope, nil, {:==, 5}, [])
  #   # :nope not in Post.__schema__(:fields)
  #   # logs: Field "nope" does not exist on schema Post, skipping
  #   ⇒ nil
  defp evaluate_field(source, binding, key, negated, {op, raw_value}, opts) do
    field_type = resolve_field_type(source, key, opts)
    value = Types.cast(field_type, raw_value)

    cond do
      invalid_schema_field?(source, key) ->
        EctoShorts.Logger.warning(
          @logger_prefix,
          "Field \"#{key}\" does not exist on schema #{inspect(CommonSchema.get_schema(source))}, skipping field reference"
        )

        nil

      map_field?(field_type) ->
        MapExpr.dynamic_expr(binding, key, negated, {op, value}, opts)

      array_field?(field_type) ->
        ArrayExpr.dynamic_expr(binding, key, negated, {op, value}, opts)

      true ->
        ScalarExpr.dynamic_expr(binding, key, negated, {op, value}, opts)
    end
  end

  # ── resolve_field_type/3 ─────────────────────────────────────────────
  # Resolves the Ecto type of `key`. Caller-supplied opts[:field_types]
  # take precedence over schema reflection — this lets schemaless
  # callers declare types per call.
  #
  # resolve_field_type(Post, :views, [])
  #   ⇒ :integer    # from Post.__schema__(:type, :views)
  #
  # resolve_field_type({"posts", nil}, :tags, field_types: [tags: {:array, :string}])
  #   ⇒ {:array, :string}
  #
  # resolve_field_type({"posts", nil}, :unknown, [])
  #   ⇒ nil
  defp resolve_field_type(source, key, opts) do
    field_types = Keyword.get(opts, :field_types, [])
    Keyword.get(field_types, key) || CommonSchema.get_schema_reflection(source, :type, key)
  end

  # ── invalid_schema_field?/2 ──────────────────────────────────────────
  # Predicate: is `key` an atom the source's schema doesn't declare?
  # Returns false when the source has no schema reflection (schemaless).
  #
  # invalid_schema_field?(Post, :views)
  #   ⇒ false       # :views in Post.__schema__(:fields)
  #
  # invalid_schema_field?(Post, :nope)
  #   ⇒ true        # :nope not in Post.__schema__(:fields)
  #
  # invalid_schema_field?({"posts", nil}, :anything)
  #   ⇒ false       # no reflection available, skip the check
  defp invalid_schema_field?(source, key) when is_atom(key) do
    case CommonSchema.get_schema_reflection(source, :fields) do
      fields when is_list(fields) -> key not in fields
      _ -> false
    end
  end

  # ── array_field?/1 / map_field?/1 ────────────────────────────────────
  # Type-shape predicates for evaluate_field/6's cond branches.
  #
  # array_field?({:array, :string})  ⇒ true
  # array_field?({:array, :integer}) ⇒ true
  # array_field?(:integer)           ⇒ false
  # array_field?(:map)               ⇒ false
  # array_field?(nil)                ⇒ false
  #
  # map_field?(:map)         ⇒ true
  # map_field?({:map, :any}) ⇒ true
  # map_field?(:integer)     ⇒ false
  # map_field?(nil)          ⇒ false

  defp array_field?({:array, _}), do: true
  defp array_field?(_), do: false

  defp map_field?(:map), do: true
  defp map_field?({:map, _}), do: true
  defp map_field?(_), do: false

  # NOTE: cast_value/2, build_rhs_entry/4, build_rhs_expr/3,
  # resolve_datetime_wrapper/3, resolve_datetime_node/3, and
  # resolve_elements_value/1 are DELETED. Every wrapper and RHS IR shape
  # they translated is now normalized in evaluate/6 above, producing tuple
  # IR for sub-modules. Sub-modules (ScalarExpr, ArrayExpr, MapExpr) receive
  # fully-normalized tuple IR and do pure pattern-dispatch — no map input,
  # no Map.to_list, no normalize_* helpers, no field-name resolution, no
  # arity validation. This module's sole responsibilities are normalization
  # (the evaluator) and dispatch (evaluate_field/6) — nothing else.

  # ── Operand IR normalization (Change 7) ──────────────────────────────
  # The router walks the Operand tree and converts it to tuple IR.
  # Binary field names are resolved to atoms here. Arity violations emit
  # a warning via arity_warn/3 and return :error; the calling evaluator
  # clause then emits nil so merge_dynamic tolerates the missing dyn.

  # ── operand_shape?/1 ─────────────────────────────────────────────────
  # Predicate: is `m` a single-entry map OR keyword list whose only key
  # is an Operand grammar key (∈ @operand_keys)?
  #
  # operand_shape?(%{add: [%{field: :a}, %{value: 1}]}) ⇒ true
  # operand_shape?([add: [%{field: :a}, %{value: 1}]])  ⇒ true   # kwlist form
  # operand_shape?(%{field: :x})                        ⇒ true
  # operand_shape?([field: :x])                         ⇒ true
  # operand_shape?(%{value: 5})                         ⇒ true
  # operand_shape?(%{abs: %{field: :y}})                ⇒ true
  # operand_shape?(%{add: [], subtract: []})            ⇒ false   # multi-entry map
  # operand_shape?([add: [], subtract: []])             ⇒ false   # multi-entry kwlist
  # operand_shape?(%{not_an_op: 1})                     ⇒ false   # key not in @operand_keys
  # operand_shape?([not_an_op: 1])                      ⇒ false
  # operand_shape?(%{})                                 ⇒ false   # zero-entry
  # operand_shape?([])                                  ⇒ false
  # operand_shape?([1, 2, 3])                           ⇒ false   # non-kwlist list
  # operand_shape?(5)                                   ⇒ false   # not a map or list
  # operand_shape?(%Ecto.Query{})                       ⇒ false   # struct
  defp operand_shape?(m) when (is_map(m) and not is_struct(m)) or is_list(m) do
    entries =
      cond do
        is_map(m) -> Map.to_list(m)
        Keyword.keyword?(m) -> m
        true -> nil
      end

    case entries do
      [{k, _}] -> k in @operand_keys
      _ -> false
    end
  end

  defp operand_shape?(_), do: false

  # ── normalize_operand/3 ──────────────────────────────────────────────
  # Recursive Operand-tree normalizer. Converts a public-API Operand
  # node (map OR single-entry keyword list, OR bare scalar) into tuple
  # IR. Binary field names are resolved to atoms via field_name_to_atom/3.
  # Map and kwlist forms are accepted at every level — operand lists
  # may contain mixed forms (a kwlist inside a map's variadic operand
  # list, etc.) and recursion handles each entry independently.
  #
  # normalize_operand(Post, %{field: :views}, [])
  #   ⇒ {:ok, {:field, :views}}
  #
  # normalize_operand(Post, [field: :views], [])
  #   ⇒ {:ok, {:field, :views}}    # kwlist Operand
  #
  # normalize_operand(Post, %{field: "views"}, [])
  #   ⇒ {:ok, {:field, :views}}    # binary resolved via reflection
  #
  # normalize_operand(Post, %{value: 5}, [])
  #   ⇒ {:ok, {:value, 5}}
  #
  # normalize_operand(Post, %{add: [%{field: :a}, %{value: 1}]}, [])
  #   ⇒ {:ok, {:add, [{:field, :a}, {:value, 1}]}}
  #
  # normalize_operand(Post, [add: [[field: :a], [value: 1]]], [])
  #   # kwlist Operand whose operand list itself contains kwlist Operands
  #   ⇒ {:ok, {:add, [{:field, :a}, {:value, 1}]}}
  #
  # normalize_operand(Post, %{add: [%{field: :a}, 1]}, [])
  #   # bare scalar 1 lifted to {:value, 1}
  #   ⇒ {:ok, {:add, [{:field, :a}, {:value, 1}]}}
  #
  # normalize_operand(Post, %{abs: %{field: :x}}, [])
  #   ⇒ {:ok, {:abs, {:field, :x}}}
  #
  # normalize_operand(Post, %{power: [%{field: :y}, %{value: 2}]}, [])
  #   ⇒ {:ok, {:power, [{:field, :y}, {:value, 2}]}}
  #
  # normalize_operand(Post, 5, [])
  #   ⇒ {:ok, {:value, 5}}    # bare scalar lifted
  #
  # normalize_operand(Post, %{add: [%{field: :a}]}, [])
  #   # warns: Operand `add` requires ≥2 operand(s)
  #   ⇒ :error
  #
  # normalize_operand(Post, %{nope: 1}, [])
  #   # warns: Unrecognized Operand shape: %{nope: 1}
  #   ⇒ :error
  #
  # normalize_operand(Post, [1, 2, 3], [])
  #   # plain list at an Operand position is malformed
  #   # warns: Unrecognized Operand shape: [1, 2, 3]
  #   ⇒ :error
  defp normalize_operand(source, node, opts)
       when (is_map(node) and not is_struct(node)) or is_list(node) do
    entries =
      cond do
        is_map(node) -> Map.to_list(node)
        Keyword.keyword?(node) -> node
        true -> nil
      end

    case entries do
      [{:field, name}] -> normalize_field_leaf(source, name, opts)
      [{:value, v}] -> {:ok, {:value, v}}
      [{op, operands}] when op in @operand_variadic_keys ->
        normalize_variadic(source, op, operands, opts)
      [{op, operands}] when op in @operand_binary_keys ->
        normalize_binary(source, op, operands, opts)
      [{op, operand}] when op in @operand_unary_keys ->
        normalize_unary(source, op, operand, opts)
      _ ->
        warn_unknown_operand(node)
        :error
    end
  end

  # Bare scalar inside an operand list — lift to {:value, v} tuple IR.
  defp normalize_operand(_source, v, _opts) when not is_map(v) and not is_list(v) do
    {:ok, {:value, v}}
  end

  # Anything else (e.g. a struct) is unrecognized.
  defp normalize_operand(_source, node, _opts) do
    warn_unknown_operand(node)
    :error
  end

  # ── normalize_field_leaf/3 ───────────────────────────────────────────
  # Resolves a field reference to {:field, atom}. Binary names are
  # resolved against schema reflection or opts[:allowed_keys] via
  # field_name_to_atom/3.
  #
  # normalize_field_leaf(Post, :views, [])
  #   ⇒ {:ok, {:field, :views}}
  #
  # normalize_field_leaf(Post, "views", [])
  #   ⇒ {:ok, {:field, :views}}     # binary validated against reflection
  #
  # normalize_field_leaf({"posts", nil}, "views", allowed_keys: ["views"])
  #   ⇒ {:ok, {:field, :views}}     # no schema, allowed via :allowed_keys
  #
  # normalize_field_leaf(Post, "no_such_field", [])
  #   # warns: Operand `field` requires valid atom or binary matching a
  #   #        schema field operand(s), got: "no_such_field"
  #   ⇒ :error
  #
  # normalize_field_leaf(Post, nil, [])
  #   ⇒ :error
  defp normalize_field_leaf(source, name, opts) do
    case field_name_to_atom(source, name, opts) do
      atom when is_atom(atom) and atom != nil -> {:ok, {:field, atom}}
      _ ->
        arity_warn(:field, "valid atom or binary matching a schema field", name)
        :error
    end
  end

  # ── normalize_variadic/4 ─────────────────────────────────────────────
  # Validates and normalizes an N-ary arithmetic operand (add, subtract,
  # multiply, divide). Requires ≥ 2 operands.
  #
  # normalize_variadic(Post, :add, [%{field: :a}, %{value: 1}], [])
  #   ⇒ {:ok, {:add, [{:field, :a}, {:value, 1}]}}
  #
  # normalize_variadic(Post, :multiply, [%{field: :a}, %{field: :b}, %{value: 2}], [])
  #   ⇒ {:ok, {:multiply, [{:field, :a}, {:field, :b}, {:value, 2}]}}
  #
  # normalize_variadic(Post, :add, [%{field: :a}], [])
  #   # warns: Operand `add` requires ≥2 operand(s), got: [%{field: :a}]
  #   ⇒ :error
  #
  # normalize_variadic(Post, :add, [], [])
  #   # warns: Operand `add` requires ≥2 operand(s), got: []
  #   ⇒ :error
  #
  # normalize_variadic(Post, :add, "not a list", [])
  #   # warns: Operand `add` requires ≥2 operand(s), got: "not a list"
  #   ⇒ :error
  defp normalize_variadic(source, op, operands, opts)
       when is_list(operands) and length(operands) >= 2 do
    normalize_operand_list(source, op, operands, opts)
  end

  defp normalize_variadic(_source, op, operands, _opts) do
    arity_warn(op, "≥2", operands)
    :error
  end

  # ── normalize_binary/4 ───────────────────────────────────────────────
  # Validates and normalizes a binary arithmetic operand (power, mod).
  # Requires exactly 2 operands.
  #
  # normalize_binary(Post, :power, [%{field: :y}, %{value: 2}], [])
  #   ⇒ {:ok, {:power, [{:field, :y}, {:value, 2}]}}
  #
  # normalize_binary(Post, :mod, [%{field: :a}, 10], [])
  #   ⇒ {:ok, {:mod, [{:field, :a}, {:value, 10}]}}
  #
  # normalize_binary(Post, :power, [%{field: :y}], [])
  #   # warns: Operand `power` requires 2 operand(s), got: [%{field: :y}]
  #   ⇒ :error
  #
  # normalize_binary(Post, :power, [%{field: :y}, %{value: 2}, %{value: 3}], [])
  #   # warns: Operand `power` requires 2 operand(s), got: [...3 elems...]
  #   ⇒ :error
  defp normalize_binary(source, op, [x, y], opts) do
    with {:ok, xi} <- normalize_operand(source, x, opts),
         {:ok, yi} <- normalize_operand(source, y, opts) do
      {:ok, {op, [xi, yi]}}
    end
  end

  defp normalize_binary(_source, op, operands, _opts) do
    arity_warn(op, 2, operands)
    :error
  end

  # ── normalize_unary/4 ────────────────────────────────────────────────
  # Validates and normalizes a unary arithmetic operand (abs, round,
  # floor, ceil, sqrt). Requires exactly 1 operand (NOT a list).
  #
  # normalize_unary(Post, :abs, %{field: :x}, [])
  #   ⇒ {:ok, {:abs, {:field, :x}}}
  #
  # normalize_unary(Post, :sqrt, %{value: 9}, [])
  #   ⇒ {:ok, {:sqrt, {:value, 9}}}
  #
  # normalize_unary(Post, :abs, 5, [])
  #   ⇒ {:ok, {:abs, {:value, 5}}}    # bare scalar lifted by inner normalize_operand
  #
  # normalize_unary(Post, :abs, [1, 2], [])
  #   # warns: Operand `abs` requires 1 operand(s), got: [1, 2]
  #   ⇒ :error
  #
  # normalize_unary(Post, :abs, %{add: [1]}, [])
  #   # inner normalize_operand fails (arity); :error propagates
  #   ⇒ :error
  defp normalize_unary(source, op, operand, opts) when not is_list(operand) do
    case normalize_operand(source, operand, opts) do
      {:ok, inner} -> {:ok, {op, inner}}
      :error -> :error
    end
  end

  defp normalize_unary(_source, op, operand, _opts) do
    arity_warn(op, 1, operand)
    :error
  end

  # ── normalize_operand_list/4 ─────────────────────────────────────────
  # Reduces over a list of operand nodes, normalizing each. Halts on the
  # first :error and propagates :error upward. Preserves operand order.
  #
  # normalize_operand_list(Post, :add, [%{field: :a}, %{value: 1}, 2], [])
  #   ⇒ {:ok, {:add, [{:field, :a}, {:value, 1}, {:value, 2}]}}
  #
  # normalize_operand_list(Post, :add, [%{field: :a}, %{nope: 1}], [])
  #   # second operand fails normalize_operand → halt + propagate
  #   ⇒ :error
  defp normalize_operand_list(source, op, operands, opts) do
    Enum.reduce_while(operands, {:ok, []}, fn operand, {:ok, acc} ->
      case normalize_operand(source, operand, opts) do
        {:ok, tuple} -> {:cont, {:ok, [tuple | acc]}}
        :error -> {:halt, :error}
      end
    end)
    |> case do
      {:ok, reversed} -> {:ok, {op, Enum.reverse(reversed)}}
      :error -> :error
    end
  end

  # ── arity_warn/3 ─────────────────────────────────────────────────────
  # Logs an arity-violation warning and returns :error.
  #
  # arity_warn(:add, "≥2", [%{field: :a}])
  #   # logs: Operand `add` requires ≥2 operand(s), got: [%{field: :a}]; skipping
  #   ⇒ :error
  #
  # arity_warn(:power, 2, [%{field: :a}])
  #   # logs: Operand `power` requires 2 operand(s), got: [%{field: :a}]; skipping
  #   ⇒ :error
  #
  # arity_warn(:abs, 1, [1, 2])
  #   # logs: Operand `abs` requires 1 operand(s), got: [1, 2]; skipping
  #   ⇒ :error
  defp arity_warn(op, required, value) do
    EctoShorts.Logger.warning(
      @logger_prefix,
      "Operand `#{op}` requires #{required} operand(s), got: #{inspect(value)}; skipping"
    )

    :error
  end

  # ── warn_unknown_operand/1 ───────────────────────────────────────────
  # Logs a warning for an Operand-shaped map whose key is not in
  # @operand_keys, or whose shape is otherwise unrecognized.
  # Return value is unused; called for its side effect.
  #
  # warn_unknown_operand(%{nope: 1})
  #   # logs: Unrecognized Operand shape: %{nope: 1}; skipping
  #   ⇒ :ok    # (Logger.warning return value)
  #
  # warn_unknown_operand(%{add: [], subtract: []})
  #   # logs: Unrecognized Operand shape: %{add: [], subtract: []}; skipping
  #   ⇒ :ok
  defp warn_unknown_operand(node) do
    EctoShorts.Logger.warning(
      @logger_prefix,
      "Unrecognized Operand shape: #{inspect(node)}; skipping"
    )
  end

  # ── op_alias/1 ───────────────────────────────────────────────────────
  # Short-op atom → canonical operator atom. Called only by
  # normalize_op/1 and the quantified-comparison clauses in evaluate/6.
  #
  # op_alias(:eq)  ⇒ :==
  # op_alias(:ne)  ⇒ :!=
  # op_alias(:gt)  ⇒ :>
  # op_alias(:gte) ⇒ :>=
  # op_alias(:lt)  ⇒ :<
  # op_alias(:lte) ⇒ :<=
  # op_alias(:foo) ⇒ FunctionClauseError    # caller must guard with `op in @short_ops`
  defp op_alias(:eq), do: :==
  defp op_alias(:ne), do: :!=
  defp op_alias(:gt), do: :>
  defp op_alias(:gte), do: :>=
  defp op_alias(:lt), do: :<
  defp op_alias(:lte), do: :<=

  # ── field_name_to_atom/3 ─────────────────────────────────────────────
  # Resolves a field name to an existing atom. Atoms pass through
  # unchanged; binaries are validated against schema reflection or
  # opts[:allowed_keys]. Called only by normalize_field_leaf/3.
  # Sub-modules never call this; they receive atoms in tuple IR.
  #
  # field_name_to_atom(Post, :views, [])
  #   ⇒ :views                       # atom passes through
  #
  # field_name_to_atom(Post, "views", [])
  #   ⇒ :views                       # binary, found in Post.__schema__(:fields)
  #
  # field_name_to_atom(Post, "nope", [])
  #   # logs: Field "nope" does not exist on schema Post, skipping field reference
  #   ⇒ nil
  #
  # field_name_to_atom({"posts", nil}, "views", allowed_keys: ["views"])
  #   ⇒ :views                       # no schema, allowed via opts
  #
  # field_name_to_atom({"posts", nil}, "views", allowed_keys: ["title"])
  #   # logs: Field "views" is not in the :allowed_keys list, skipping field reference
  #   ⇒ nil
  #
  # field_name_to_atom({"posts", nil}, "views", [])
  #   # logs: Field "views" cannot be resolved: no schema or :allowed_keys available
  #   ⇒ nil
  defp field_name_to_atom(_source, field_name, _opts) when is_atom(field_name), do: field_name

  defp field_name_to_atom(source, field_name, opts) when is_binary(field_name) do
    # unchanged — see current implementation
  end

  # ── merge_dynamic/3 ──────────────────────────────────────────────────
  # AND/OR merger for dynamic expressions. Tolerates nil on either side
  # so reducers can start from nil and pass through a missing dyn.
  #
  # # given dyn1 = dynamic([p], p.views > 5)
  # #       dyn2 = dynamic([p], p.views < 100)
  #
  # merge_dynamic(nil, :and, dyn1)
  #   ⇒ dyn1                                        # nil left side passes through
  #
  # merge_dynamic(dyn1, :and, nil)
  #   ⇒ dyn1                                        # nil right side passes through
  #
  # merge_dynamic(nil, :and, nil)
  #   ⇒ nil                                         # both nil → nil
  #
  # merge_dynamic(dyn1, :and, dyn2)
  #   ⇒ dynamic([p], p.views > 5 and p.views < 100)
  #
  # merge_dynamic(dyn1, :or, dyn2)
  #   ⇒ dynamic([p], p.views > 5 or p.views < 100)
  defp merge_dynamic(nil, _, b), do: b
  defp merge_dynamic(a, _, nil), do: a
  defp merge_dynamic(a, :and, b), do: dynamic(^a and ^b)
  defp merge_dynamic(a, :or, b), do: dynamic(^a or ^b)
end
```

### Summary of what changed vs. before

**Architecture:** `apply_expr/4` + `dispatch_expr/6` (~15 clauses) + `dispatch_field_expr/6` replaced by `walk/6` + `evaluate/6` + `evaluate_field/6`. The walker collapses single-entry containers and fans out multi-entry containers in one recursive descent — no second flatten pass. The evaluator pattern-matches the aggregated tuple once per leaf.

| Removed | Reason |
|---|---|
| `alias EctoShorts.CommonFilters`, `alias EctoShorts.CommonFilters.Select` | No longer called from here (Change 2) |
| `build_quantified_query/3`, `subquery_spec?/1` | Moved to `CommonFilters` (Change 2) |
| `apply_expr/4` | Replaced by `walk/6` (Change 6) |
| `dispatch_expr/6` (all ~15 clauses) | Replaced by `walk/6` + `evaluate/6` (Change 6) |
| `dispatch_field_expr/6` | Renamed to `evaluate_field/6` with simplified body (Changes 3 + 6) |
| `field_type` resolution in `build_dynamic/4` | Moved to `resolve_field_type/3`; one call site (Change 1) |
| Per-clause `Enum.map \|> Enum.reduce` pairs | Collapsed into single `Enum.reduce` in `walk/6` (Changes 1 + 5) |
| `canonical = cond do ...` blocks in `dispatch_field_expr` | `evaluate_field/6` always receives `{op, value}` (Change 3) |
| `array_field?/3`, `map_field?/3` re-resolution | Take pre-resolved `field_type` (Change 3) |
| `cast_value/2` (all 14 clauses) | `Types.cast` called once directly in `evaluate_field/6` after all wrapper normalization completes |
| `build_rhs_entry/4` (all clauses) | Wrapper + Operand normalization now lives in `evaluate/6` (router), not a helper |
| `build_rhs_expr/3` (all clauses) | Same reason as `build_rhs_entry/4` |
| `resolve_datetime_wrapper/3`, `resolve_datetime_node/3` | Datetime wrapper normalization moves to an `evaluate/6` clause (router owns all wrapper normalization) |
| `:arithmetic` evaluator clause | Replaced by the Operand RHS shape, normalized in the router and dispatched by `ScalarExpr` tuple-IR clauses (Change 7) |
| All exact-shape matches (5 locations) | Entry-boundary reduces in the router, or `Map.fetch!`-style single-entry helpers (Changes 4a–4d + 2) |

| Added / changed visibility | Reason |
|---|---|
| `walk/6` | Single-pass traversal — top-level fan-out only, normalizes short-ops inline, AND/OR-merges dyns (Change 6). Signature `(source, binding, key, negated, term, opts)` aligned with `evaluate/6` and `evaluate_field/6`. |
| `evaluate/6` | Single routing + normalization function. One clause per public-API shape. Owns datetime-wrapper normalization, `parent_as` normalization, Operand RHS tree normalization (recursive map-to-tuple), transform/aggregate/elements/quantifier normalization, and generic map-to-keyword-list fan-out for non-Operand comparison RHS (Changes 6 + 7). Same aligned signature. |
| `evaluate_field/6` | Field-level router; single call site for `Types.cast/2` in the entire module. Receives only tuple IR (Changes 3 + 6). Same aligned signature. |
| `resolve_field_type/3` | Single call site for field type resolution (Change 1) |
| `normalize_op/1` | Short-op alias table used inline at each lift in `walk/6` |
| `@transform_ops`, `@datetime_wrappers`, `@comparison_operators` module attributes | Explicit guard lists for evaluator clauses |
| `@operand_leaf_keys`, `@operand_variadic_keys`, `@operand_binary_keys`, `@operand_unary_keys`, `@operand_keys` | Operand grammar keys for the router's Operand-shape detection and normalization (Change 7) |
| `operand_shape?/1`, `normalize_operand/3`, `normalize_field_leaf/3`, `normalize_variadic/4`, `normalize_binary/4`, `normalize_unary/4`, `normalize_operand_list/4` | Private helpers implementing Operand-tree normalization in the router (Change 7) |
| `arity_warn/3`, `warn_unknown_operand/1` | Private helpers for skip + warn paths in the Operand normalizer |
| `field_name_to_atom/3` stays **private** | Called only by `normalize_field_leaf/3` in the router's Operand normalizer. Sub-modules never call it; they receive atoms in tuple IR. |

---

## Projected final state of `lib/ecto_shorts/common_filters.ex`

Three surgical changes to the 539-line file: one new alias, one modified branch in `apply_filter/6`, five new private functions appended. Everything else is unchanged. The full projected module:

```elixir
defmodule EctoShorts.CommonFilters do
  @moduledoc since: "3.0.0"
  @moduledoc """
  Converts public filter params into an `Ecto.Query`.

  (… docstring unchanged from the current file — lines 3–223 …)
  """

  alias EctoShorts.CommonQuery
  alias EctoShorts.CommonSchema
  alias EctoShorts.Config

  alias EctoShorts.CommonFilters.Builder
  alias EctoShorts.CommonFilters.Select    # ← new

  @logger_prefix "EctoShorts.CommonFilters"

  # (… @type filters, @filters, filters/0 — unchanged, lines 233–308 …)

  # ------------------------------------------------------------------------
  # IMPLEMENTATION CONTRACT  (unchanged — lines 310–338)
  # ------------------------------------------------------------------------

  # (… @doc / @spec for convert_params_to_filter/3 unchanged — lines 340–379 …)
  def convert_params_to_filter(source, params, opts \\ []) do
    query = CommonSchema.to_query(source)

    sorted =
      case opts[:sorter] do
        nil -> sort_filter_params(params)
        sorter -> sorter.(params)
      end

    reduce_filters(:where, source, query, {:as, nil}, sorted, opts)
  end

  defp reduce_filters(filter, source, query, selected_binding, params, opts) do
    Enum.reduce(params, query, &apply_filter(filter, source, &2, selected_binding, &1, opts))
  end

  defp apply_filter(filter, source, query, selected_binding, {key, params}, opts) do
    cond do
      key in [:as, :at] ->
        Enum.reduce(params, query, fn {next_key, next_value}, query_acc ->
          case resolve_binding_selector(query_acc, key, next_key) do
            :error ->
              query_acc

            {:ok, resolved} ->
              apply_filter(
                filter,
                source,
                query_acc,
                resolved,
                next_value,
                opts
              )
          end
        end)

      key in [:having, :or_having, :where, :or_where] ->
        cond do
          list_of_params?(params) ->
            reduce_filters(key, source, query, selected_binding, params, opts)

          params?(params) ->
            reduce_filters(key, source, query, selected_binding, params, opts)

          true ->
            Builder.build_query(key, source, query, selected_binding, params, opts)
        end

      assoc_key?(source, key) ->
        if params?(params) do
          apply_assoc_filters(filter, source, query, key, params, opts)
        else
          EctoShorts.Logger.warning(
            @logger_prefix,
            "Expected association filter value to be a map or keyword list, got: #{inspect(params)}"
          )

          query
        end

      key === :and ->
        reduce_filters(filter, source, query, selected_binding, params, opts)

      key === :or ->
        if list_of_params?(params) do
          reduce_filters(:or_where, source, query, selected_binding, params, opts)
        else
          Enum.reduce(params, query, fn {inner_key, inner_value}, query_acc ->
            or_entries(source, query_acc, selected_binding, inner_key, inner_value, opts)
          end)
        end

      key in @filters ->
        Builder.build_query(key, source, query, selected_binding, params, opts)

      # ← CHANGED: resolve any subquery spec before dispatching.
      true ->
        resolved = resolve_quantifier_subquery(key, params, opts)
        Builder.build_query(filter, source, query, selected_binding, {key, resolved}, opts)
    end
  end

  defp apply_filter(filter, source, query, selected_binding, params, opts) do
    reduce_filters(filter, source, query, selected_binding, params, opts)
  end

  defp or_entries(source, query, selected_binding, key, value, opts) do
    Builder.build_query(:or_where, source, query, selected_binding, {key, value}, opts)
  end

  defp apply_assoc_filters(filter, source, query, key, params, opts) do
    assoc_source = get_assoc_source(source, key)

    query_acc =
      Builder.build_query(
        :join,
        source,
        query,
        {:as, nil},
        [association: [source: key, as: key]],
        opts
      )

    apply_filter(filter, assoc_source, query_acc, {:as, key}, params, opts)
  end

  defp resolve_binding_selector(_query, :at, :first) do
    {:ok, {:at, 1}}
  end

  defp resolve_binding_selector(query, :at, :last) do
    {:ok, {:at, CommonQuery.query_binding_count(query)}}
  end

  defp resolve_binding_selector(_query, :at, position) when is_integer(position) do
    max = Config.max_positional_bindings() || 10

    if position >= 1 and position <= max do
      {:ok, {:at, position}}
    else
      EctoShorts.Logger.warning(
        @logger_prefix,
        "Positional binding :at position #{position} is out of range " <>
          "(compiled max: #{max}). Filter skipped."
      )

      :error
    end
  end

  defp resolve_binding_selector(_query, key, inner_key) do
    {:ok, {key, inner_key}}
  end

  defp get_assoc_source(source, key) do
    %{queryable: queryable} = CommonSchema.get_schema_reflection(source, :association, key)
    queryable
  end

  defp assoc_key?(source, key) do
    key in (CommonSchema.get_schema_reflection(source, :associations) || [])
  end

  defp params?(term), do: (is_map(term) and not is_struct(term)) or Keyword.keyword?(term)
  defp list_of_params?([]), do: true
  defp list_of_params?([head | _]), do: params?(head)
  defp list_of_params?(_), do: false

  defp sort_filter_params(params) do
    where_filters = Enum.filter(params, fn {key, _val} -> key === :where end)
    or_where_filters = Enum.filter(params, fn {key, _val} -> key === :or_where end)
    terminal_filters = Enum.filter(params, fn {key, _val} -> key in [:last, :subquery] end)

    other_filters =
      Enum.filter(params, fn {key, _val} -> key not in [:where, :or_where, :last, :subquery] end)

    where_filters
    |> Kernel.++(other_filters)
    |> Kernel.++(or_where_filters)
    |> Kernel.++(terminal_filters)
  end

  # ── New helpers appended at the bottom (Change 2) ────────────────────────

  # ── resolve_quantifier_subquery/3 ────────────────────────────────────
  # Detects an `:all` / `:any` payload that carries a subquery spec
  # (any term matching subquery_spec?/1) and replaces the spec with the
  # built `Ecto.Query`. Non-spec payloads pass through unchanged. Used
  # in apply_filter/6's fallback branch right before Builder dispatch.
  #
  # # given a spec %{from: Comment, post_id: 1} — has :from → spec
  # resolve_quantifier_subquery(:id,
  #   {:any, %{from: Comment, post_id: 1}}, [])
  #   ⇒ {:any, %Ecto.Query{from: Comment, ...}}    # spec built
  #
  # resolve_quantifier_subquery(:id,
  #   {:>, {:all, [from: Comment, views: 100]}}, [])
  #   ⇒ {:>, {:all, %Ecto.Query{from: Comment, ...}}}
  #
  # resolve_quantifier_subquery(:id, {:any, [1, 2, 3]}, [])
  #   ⇒ {:any, [1, 2, 3]}                          # not a spec, passes through
  #
  # resolve_quantifier_subquery(:id, {:>, 5}, [])
  #   ⇒ {:>, 5}                                    # no quantifier, passes through
  defp resolve_quantifier_subquery(key, {quantifier, payload}, opts)
       when quantifier in [:all, :any] do
    if subquery_spec?(payload),
      do: {quantifier, build_quantified_subquery(key, payload, opts)},
      else: {quantifier, payload}
  end

  defp resolve_quantifier_subquery(key, {op, {quantifier, payload}}, opts)
       when quantifier in [:all, :any] do
    if subquery_spec?(payload),
      do: {op, {quantifier, build_quantified_subquery(key, payload, opts)}},
      else: {op, {quantifier, payload}}
  end

  defp resolve_quantifier_subquery(_key, params, _opts), do: params

  # ── subquery_spec?/1 ─────────────────────────────────────────────────
  # Predicate: does `payload` carry a `:from` key, marking it as a
  # subquery specification? Maps and keyword lists may both qualify.
  #
  # subquery_spec?(%{from: Comment, post_id: 1})       ⇒ true
  # subquery_spec?([from: Comment, post_id: 1])        ⇒ true
  # subquery_spec?(%{post_id: 1})                      ⇒ false   # no :from
  # subquery_spec?([post_id: 1])                       ⇒ false   # no :from
  # subquery_spec?([1, 2, 3])                          ⇒ false   # not a kwlist
  # subquery_spec?(%Ecto.Query{})                      ⇒ false   # struct, not a spec
  # subquery_spec?(5)                                  ⇒ false
  defp subquery_spec?(payload) when is_map(payload) and not is_struct(payload),
    do: Map.has_key?(payload, :from)

  defp subquery_spec?(payload) when is_list(payload),
    do: Keyword.keyword?(payload) and Keyword.has_key?(payload, :from)

  defp subquery_spec?(_payload), do: false

  # ── build_quantified_subquery/3 ──────────────────────────────────────
  # Materializes a subquery-spec map or keyword list into an Ecto.Query
  # by recursing through `convert_params_to_filter/3` for the where part
  # and projecting the chosen `:select` field via `Select.build_query/6`.
  #
  # The outer field key (the LHS of the comparison this subquery is
  # being compared against) is the default `:select` projection when
  # the spec doesn't specify one.
  #
  # # given a Comment schema with fields [:post_id, :views, ...]
  #
  # build_quantified_subquery(:id,
  #   %{from: Comment, post_id: 1}, [])
  #   ⇒ %Ecto.Query{from: Comment, where: [post_id == 1], select: c.id}
  #   # outer_key :id used as default select
  #
  # build_quantified_subquery(:id,
  #   [from: Comment, select: :post_id, post_id: 1], [])
  #   ⇒ %Ecto.Query{from: Comment, where: [post_id == 1], select: c.post_id}
  #
  # build_quantified_subquery(:id,
  #   [from: Comment, select: "post_id", post_id: 1], [])
  #   # binary "post_id" matched against Comment.__schema__(:fields)
  #   ⇒ %Ecto.Query{from: Comment, ..., select: c.post_id}
  #
  # build_quantified_subquery(:id,
  #   [from: Comment, select: %{field: :post_id}, post_id: 1], [])
  #   ⇒ %Ecto.Query{from: Comment, ..., select: c.post_id}
  #
  # build_quantified_subquery(:id, %{from: Comment}, [])
  #   ⇒ %Ecto.Query{from: Comment, select: c.id}    # no where, falls through to outer_key
  #
  # build_quantified_subquery(:id, "not a map or kwlist", [])
  #   # logs: Expected a map or keyword list, got: "not a map or kwlist"
  #   ⇒ "not a map or kwlist"     # original term returned
  defp build_quantified_subquery(outer_key, params, opts)
       when is_map(params) and not is_struct(params) do
    build_quantified_subquery(outer_key, Map.to_list(params), opts)
  end

  defp build_quantified_subquery(outer_key, params, opts) do
    if Keyword.keyword?(params) do
      {source, params_without_from} = Keyword.pop(params, :from, [])
      {select_spec, where_params} = Keyword.pop(params_without_from, :select)

      select_term =
        case select_spec || outer_key do
          field when is_atom(field) and field !== nil ->
            field

          field when is_binary(field) ->
            fields = CommonSchema.get_schema_reflection(source, :fields) || []
            Enum.find(fields, &(Atom.to_string(&1) == field)) || outer_key

          params ->
            if (is_map(params) and not is_struct(params)) or Keyword.keyword?(params) do
              field_atom = params[:field]
              if is_atom(field_atom) and field_atom != nil, do: field_atom, else: outer_key
            else
              outer_key
            end
        end

      inner_query = convert_params_to_filter(source, where_params, opts)
      Select.build_query(:select, source, inner_query, {:as, nil}, select_term, opts)
    else
      EctoShorts.Logger.warning(
        @logger_prefix,
        "Expected a map or keyword list, got: #{inspect(params)}"
      )

      params
    end
  end
end
```

Ellipses `(…)` mark regions carried over verbatim from the current file. Every line outside those regions is shown literally. The three changes:

| Line region | Change |
|---|---|
| 229 (alias block) | Add `alias EctoShorts.CommonFilters.Select` |
| 455–456 (`apply_filter/6` fallback) | Resolve subquery spec via `resolve_quantifier_subquery/3` before dispatching to `Builder` |
| Bottom of module | Append 5 private function heads: `resolve_quantifier_subquery/3`, `subquery_spec?/1`, `build_quantified_subquery/3` |

---

## Projected final state of `lib/ecto_shorts/dynamic_builders/postgres/scalar_expr.ex`

Shown as a delta against the current 833-line file because the bulk of the module is unchanged. `ScalarExpr` receives **only fully-normalized tuple IR** from the router — every Operand shape, datetime wrapper, and `parent_as` payload is a tuple by the time it arrives. The sub-module performs **pure pattern-dispatch** and tuple-to-SQL emission. It has no map-form clauses, no `Map.to_list`, no `Keyword.new`, no `field_name_to_atom` call, no arity validation, and no `normalize_*` helpers.

The changes are contained to three regions:

| Region | Lines in current file | Change |
|---|---|---|
| `family_for/2` | 799–820 | Add one clause that detects tuple-IR Operand RHS and routes to a new `:arithmetic` family |
| `comparison_impl/4` — arithmetic + `:value` wrapper clauses | 571–593 | Delete the legacy `{op_a, {:value, {arith_op, {{:field, af}, {:value, av}}}}}` clause and its negated twin (the old `:arithmetic` wrapper shape is gone). The bare `{op_v, {:value, v}}` clauses stay — they are already tuple IR and remain the canonical scalar literal dispatch. |
| `apply_arith_comparison/6` | 681–728 | Delete all 48 clauses — replaced by tuple-IR dispatch |
| New section at bottom | — | Add `arithmetic_impl/4` plus `build_operand_dyn/2` — a pure recursive tuple-to-SQL emitter. No IR translation, no field-name resolution, no arity validation (all done in the router before the tuple arrives). |

Everything else — `dynamic_expr/5` entry, binding-specific helpers (lines 22–128), `dispatch_expr/4`, `membership_impl`, `string_transform_impl`, `string_impl`, the non-arithmetic branches of `comparison_impl`, `apply_scalar_comparison`, `apply_parent_as_comparison`, `apply_dyn_comparison`, `apply_datetime_comparison`, `agg_field_dyn`, `preserve_or_wrap_pattern` — is retained verbatim.

### 1. `family_for/2` — add Operand detection

**Before (lines 799–820):**

```elixir
defp family_for(:in, _term), do: :membership

defp family_for(op, value) when op in @equality_operators and is_list(value) do
  :membership
end

defp family_for(op, {transform, _term})
     when op in @comparison_operators and transform in [:lower, :upper] do
  :string_transform
end

defp family_for(op, term) when op in @string_operators do
  case term do
    {transform, _term} when transform in [:lower, :upper] ->
      :string_transform

    _ ->
      :string
  end
end

defp family_for(_op, _term), do: :comparison
```

**After:**

```elixir
defp family_for(:in, _term), do: :membership

defp family_for(op, value) when op in @equality_operators and is_list(value) do
  :membership
end

defp family_for(op, {transform, _term})
     when op in @comparison_operators and transform in [:lower, :upper] do
  :string_transform
end

defp family_for(op, term) when op in @string_operators do
  case term do
    {transform, _term} when transform in [:lower, :upper] ->
      :string_transform

    _ ->
      :string
  end
end

# ── family_for/2 — :arithmetic clause (NEW) ───────────────────────────
# Tuple-IR Operand RHS routes to arithmetic. The router normalizes
# map-form Operand trees to tuple IR before they arrive here; ScalarExpr
# only ever sees atoms (for :field leaves) and tuples (for every node).
#
# family_for(:>, {:add, [{:field, :base}, {:value, 5}]})
#   ⇒ :arithmetic
# family_for(:==, {:abs, {:field, :y}})
#   ⇒ :arithmetic
# family_for(:==, {:value, 5})
#   ⇒ :arithmetic
# family_for(:==, {:field, :y})
#   ⇒ :arithmetic
# family_for(:>, 5)
#   ⇒ :comparison    # not a tuple, falls through to default clause
# family_for(:in, [1, 2, 3])
#   ⇒ :membership    # earlier clause matches first
defp family_for(op, {operand_key, _}) when op in @comparison_operators and operand_key in @operand_keys do
  :arithmetic
end

defp family_for(_op, _term), do: :comparison

# ScalarExpr's copy of the grammar keys — used purely for dispatch.
# Normalization lives in the router; this list is only for pattern matching.
@operand_keys [
  :field,
  :value,
  :add,
  :subtract,
  :multiply,
  :divide,
  :power,
  :mod,
  :abs,
  :round,
  :floor,
  :ceil,
  :sqrt
]
```

And add the `:arithmetic` case to `dispatch_expr/4`:

```elixir
# ── dispatch_expr/4 — family-router (NEW :arithmetic case) ────────────
# Top-level family router. family_for/2 inspects the {op, value} tuple
# and returns one of five family atoms; this case dispatches to the
# matching impl. Returns a dynamic_expr | nil.
#
# dispatch_expr({:as, nil}, :score, nil, {:>, {:add, [{:field, :base}, {:value, 5}]}})
#   # family_for/2 ⇒ :arithmetic
#   ⇒ arithmetic_impl({:as, nil}, :score, nil, {:>, {:add, [{:field, :base}, {:value, 5}]}})
#   ⇒ dynamic([p], p.score > p.base + 5)
#
# dispatch_expr({:as, nil}, :views, nil, {:>, 5})
#   # family_for/2 ⇒ :comparison
#   ⇒ comparison_impl(... {:>, 5})
#   ⇒ dynamic([p], p.views > 5)
#
# dispatch_expr({:as, nil}, :tags, nil, {:in, ["a", "b"]})
#   # family_for/2 ⇒ :membership
#   ⇒ membership_impl(... {:in, ["a", "b"]})
defp dispatch_expr(binding, key, negated, {op, value}) do
  case family_for(op, value) do
    :membership -> membership_impl(binding, key, negated, {op, value})
    :string_transform -> string_transform_impl(binding, key, negated, {op, value})
    :string -> string_impl(binding, key, negated, {op, value})
    :arithmetic -> arithmetic_impl(binding, key, negated, {op, value})   # ← NEW
    :comparison -> comparison_impl(binding, key, negated, {op, value})
  end
end
```

### 2. `comparison_impl/4` — delete the legacy arithmetic wrapper clauses

**Delete these two clauses from the `case term do` block (current lines 571–593):**

```elixir
# DELETE — the legacy {:value, {arith_op, {{:field, af}, {:value, av}}}}
# shape is gone. Operand RHS arrives here as {op, tuple_ir} already (the
# router has normalized it); arithmetic_impl/4 handles those cases via
# family_for/2 routing.
{op_a, {:value, {arith_op, {{:field, af}, {:value, av}}}}}
when op_a in @comparison_operators and arith_op in [:+, :-, :*, :/] and is_atom(af) and
       af !== nil ->
  f = field_dyn(binding, key)
  f2 = field_dyn(binding, af)
  apply_arith_comparison(op_a, f, f2, arith_op, av, :plain)

{:not, {op_a, {:value, {arith_op, {{:field, af}, {:value, av}}}}}}
when op_a in @comparison_operators and arith_op in [:+, :-, :*, :/] and is_atom(af) and
       af !== nil ->
  f = field_dyn(binding, key)
  f2 = field_dyn(binding, af)
  apply_arith_comparison(op_a, f, f2, arith_op, av, :negated)
```

The bare `{op_v, {:value, v}}` clauses (and their negated twins) are **retained** — they dispatch the `{:value, v}` tuple IR produced by the router's Operand normalizer for literal-value RHS. No change required.

### 3. `apply_arith_comparison/6` — delete all 48 clauses (lines 681–728)

Entire function removed. Operand tuple IR generates the same SQL via `arithmetic_impl/4` + `build_operand_dyn/2` + `apply_dyn_comparison/4`.

### 4. New section at bottom — tuple-IR Operand dispatcher

Inserted after `apply_datetime_comparison/7` (current line 782) and before `apply_dyn_comparison/4`:

```elixir
# ── Tuple-IR Operand dispatch (Change 7) ──────────────────────────────────
#
# ScalarExpr receives tuple IR from the router — every Operand node is a
# tuple, every :field leaf carries an atom, every operand-list arity is
# validated. This code does NOT walk map-form Operand trees, resolve field
# names, or validate arity. It emits Ecto dynamic expressions from already-
# canonical tuples.
#
# arithmetic_impl/4 is the entry point from family_for/2's :arithmetic
# routing. build_operand_dyn/2 is a pure recursive tuple-to-SQL emitter —
# it pattern-matches one clause per Operand tuple shape and returns an
# Ecto.Query.dynamic_expr/0. Unknown tuple shapes (which indicate a router
# bug rather than user input) return nil so merge_dynamic tolerates them.

# ── arithmetic_impl/4 ─────────────────────────────────────────────────
# Entry point from family_for/2's :arithmetic routing. Builds the LHS
# field reference, builds the RHS via build_operand_dyn/2 (recursive
# tuple-to-SQL emitter), and runs the comparison via apply_dyn_comparison/4.
# Returns nil when build_operand_dyn returns nil (router-bug guard).
#
# arithmetic_impl({:as, nil}, :score, nil, {:>, {:add, [{:field, :base}, {:value, 5}]}})
#   # lhs = p.score; rhs_dyn = p.base + 5
#   ⇒ dynamic([p], p.score > p.base + 5)
#
# arithmetic_impl({:as, nil}, :score, :not, {:>, {:add, [{:field, :base}, {:value, 5}]}})
#   ⇒ dynamic([p], not (p.score > p.base + 5))
#
# arithmetic_impl({:as, nil}, :score, nil, {:==, {:abs, {:field, :y}}})
#   ⇒ dynamic([p], p.score == fragment("ABS(?)", p.y))
defp arithmetic_impl(binding, key, negated, {op, operand_tuple}) do
  lhs = field_dyn(binding, key)

  case build_operand_dyn(binding, operand_tuple) do
    nil ->
      nil

    rhs_dyn ->
      mode = if negated === :not, do: :negated, else: :plain
      apply_dyn_comparison(op, lhs, rhs_dyn, mode)
  end
end

# ── build_operand_dyn/2 ───────────────────────────────────────────────
# Pure recursive tuple-to-SQL emitter. One clause per Operand tuple
# shape; returns an Ecto dynamic expression or nil for unknown tuples.
# Does NOT walk maps, resolve field names, or validate arity — the
# router has already done all of that.

# Leaf: field reference — atom already resolved by the router.
#
# build_operand_dyn({:as, nil}, {:field, :views})
#   ⇒ dynamic([p], p.views)
defp build_operand_dyn(binding, {:field, atom}) when is_atom(atom) do
  field_dyn(binding, atom)
end

# Leaf: literal value.
#
# build_operand_dyn({:as, nil}, {:value, 5})
#   ⇒ dynamic([], ^5)
# build_operand_dyn({:as, nil}, {:value, "abc"})
#   ⇒ dynamic([], ^"abc")
defp build_operand_dyn(_binding, {:value, v}) do
  dynamic([], ^v)
end

# Variadic: add / subtract / multiply / divide. Router guarantees ≥ 2
# operands. Fold left-to-right via fold_variadic/3.
#
# build_operand_dyn({:as, nil}, {:add, [{:field, :a}, {:value, 5}]})
#   ⇒ dynamic([p], p.a + 5)
# build_operand_dyn({:as, nil}, {:add, [{:field, :a}, {:field, :b}, {:value, 1}]})
#   ⇒ dynamic([p], p.a + p.b + 1)
# build_operand_dyn({:as, nil}, {:subtract, [{:field, :a}, {:value, 1}]})
#   ⇒ dynamic([p], p.a - 1)
# build_operand_dyn({:as, nil}, {:multiply, [{:field, :a}, {:value, 2}]})
#   ⇒ dynamic([p], p.a * 2)
# build_operand_dyn({:as, nil}, {:divide, [{:field, :a}, {:value, 2}]})
#   ⇒ dynamic([p], p.a / 2)
defp build_operand_dyn(binding, {:add, operands}) when is_list(operands) do
  fold_variadic(binding, operands, fn a, b -> dynamic([], ^a + ^b) end)
end

defp build_operand_dyn(binding, {:subtract, operands}) when is_list(operands) do
  fold_variadic(binding, operands, fn a, b -> dynamic([], ^a - ^b) end)
end

defp build_operand_dyn(binding, {:multiply, operands}) when is_list(operands) do
  fold_variadic(binding, operands, fn a, b -> dynamic([], ^a * ^b) end)
end

defp build_operand_dyn(binding, {:divide, operands}) when is_list(operands) do
  fold_variadic(binding, operands, fn a, b -> dynamic([], ^a / ^b) end)
end

# Binary: power, mod. Router guarantees exactly 2 operands. nil-guard
# the recursive results so a router bug skips the dyn instead of crashing.
#
# build_operand_dyn({:as, nil}, {:power, [{:field, :y}, {:value, 2}]})
#   ⇒ dynamic([p], fragment("POWER(?, ?)", p.y, ^2))
# build_operand_dyn({:as, nil}, {:mod, [{:field, :a}, {:value, 10}]})
#   ⇒ dynamic([p], fragment("MOD(?, ?)", p.a, ^10))
defp build_operand_dyn(binding, {:power, [x, y]}) do
  with xd when xd != nil <- build_operand_dyn(binding, x),
       yd when yd != nil <- build_operand_dyn(binding, y) do
    dynamic([], fragment("POWER(?, ?)", ^xd, ^yd))
  end
end

defp build_operand_dyn(binding, {:mod, [x, y]}) do
  with xd when xd != nil <- build_operand_dyn(binding, x),
       yd when yd != nil <- build_operand_dyn(binding, y) do
    dynamic([], fragment("MOD(?, ?)", ^xd, ^yd))
  end
end

# Unary: abs, round, floor, ceil, sqrt. Router guarantees single operand.
# One clause per SQL fragment because Ecto fragment strings must be
# compile-time literals.
#
# build_operand_dyn({:as, nil}, {:abs, {:field, :x}})
#   ⇒ dynamic([p], fragment("ABS(?)", p.x))
# build_operand_dyn({:as, nil}, {:round, {:field, :x}})
#   ⇒ dynamic([p], fragment("ROUND(?)", p.x))
# build_operand_dyn({:as, nil}, {:floor, {:field, :x}})
#   ⇒ dynamic([p], fragment("FLOOR(?)", p.x))
# build_operand_dyn({:as, nil}, {:ceil, {:field, :x}})
#   ⇒ dynamic([p], fragment("CEIL(?)", p.x))
# build_operand_dyn({:as, nil}, {:sqrt, {:value, 9}})
#   ⇒ dynamic([], fragment("SQRT(?)", ^9))
defp build_operand_dyn(binding, {:abs, inner}) do
  case build_operand_dyn(binding, inner) do
    nil -> nil
    dyn -> dynamic([], fragment("ABS(?)", ^dyn))
  end
end

defp build_operand_dyn(binding, {:round, inner}) do
  case build_operand_dyn(binding, inner) do
    nil -> nil
    dyn -> dynamic([], fragment("ROUND(?)", ^dyn))
  end
end

defp build_operand_dyn(binding, {:floor, inner}) do
  case build_operand_dyn(binding, inner) do
    nil -> nil
    dyn -> dynamic([], fragment("FLOOR(?)", ^dyn))
  end
end

defp build_operand_dyn(binding, {:ceil, inner}) do
  case build_operand_dyn(binding, inner) do
    nil -> nil
    dyn -> dynamic([], fragment("CEIL(?)", ^dyn))
  end
end

defp build_operand_dyn(binding, {:sqrt, inner}) do
  case build_operand_dyn(binding, inner) do
    nil -> nil
    dyn -> dynamic([], fragment("SQRT(?)", ^dyn))
  end
end

# Unknown tuple shape — should never occur if the router's normalizer
# is correct. Emits nil rather than raising; merge_dynamic tolerates nil.
#
# build_operand_dyn(_, {:nope, 1})  ⇒ nil
# build_operand_dyn(_, "garbage")   ⇒ nil
defp build_operand_dyn(_binding, _other), do: nil

# ── fold_variadic/3 ───────────────────────────────────────────────────
# Left-to-right fold of variadic operand lists. Builds each operand's
# dyn via build_operand_dyn/2, then combines pairwise with `combiner`.
# Skips nil dyns silently (router bug guard). Assumes router-validated
# arity (length ≥ 2).
#
# fold_variadic({:as, nil}, [{:field, :a}, {:value, 1}, {:value, 2}],
#               fn a, b -> dynamic([], ^a + ^b) end)
#   # operand 1: dynamic([p], p.a)
#   # operand 2: dynamic([], ^1) → combine: dynamic([p], p.a + 1)
#   # operand 3: dynamic([], ^2) → combine: dynamic([p], p.a + 1 + 2)
#   ⇒ dynamic([p], p.a + 1 + 2)
#
# fold_variadic({:as, nil}, [{:field, :a}, {:value, 1}],
#               fn a, b -> dynamic([], ^a * ^b) end)
#   ⇒ dynamic([p], p.a * 1)
defp fold_variadic(binding, operands, combiner) do
  Enum.reduce(operands, nil, fn operand, acc ->
    case build_operand_dyn(binding, operand) do
      nil -> acc
      dyn when acc === nil -> dyn
      dyn -> combiner.(acc, dyn)
    end
  end)
end
```

**Note on fragments:** Ecto fragment strings must be compile-time literals, so each of the binary and unary ops gets its own `build_operand_dyn/2` clause with the fragment string inlined. There is no parameterized helper because the compiler requires the literal.

### Verification

After this refactor:

| Public filter input | Router emits tuple IR | Expected SQL |
|---|---|---|
| `%{score: %{gt: %{add: [%{field: "base"}, %{value: 5}]}}}` | `{:>, {:add, [{:field, :base}, {:value, 5}]}}` | `score > (base + 5)` |
| `%{x: %{eq: %{abs: %{field: :y}}}}` | `{:==, {:abs, {:field, :y}}}` | `x = ABS(y)` |
| `%{x: %{eq: %{power: [%{field: :y}, %{value: 2}]}}}` | `{:==, {:power, [{:field, :y}, {:value, 2}]}}` | `x = POWER(y, 2)` |
| `%{x: %{gt: %{add: [%{field: :y}, 5]}}}` | `{:>, {:add, [{:field, :y}, {:value, 5}]}}` (router lifts bare `5`) | `x > (y + 5)` |
| `%{x: %{gt: 5}}` | `{:>, 5}` (no Operand; routes to `:comparison` family) | `x > 5` |
| `%{x: %{gt: %{add: []}}}` | router emits `nil`, warns | skipped |
| `%{x: %{gt: %{power: [1]}}}` | router emits `nil`, warns | skipped |

---

## Projected final state of `lib/ecto_shorts/dynamic_builders/postgres/array_expr.ex`

**No changes vs. current source.** `ArrayExpr` already dispatches on tuple IR for every shape it handles. The `:elements` wrapper routing signal arrives from `Postgres.evaluate_field/6` as the already-unwrapped `{op, value}` tuple (see the `{:elements, {_, _} = inner}` clause in `evaluate_field/6`). All inputs are tuple IR; there is no map-form handling. `parent_as` arrives as `{:parent_as, {b, f}}` — already normalized by the router — and matches the existing tuple-IR clauses in this file verbatim.

```elixir
defmodule EctoShorts.DynamicBuilders.Postgres.ArrayExpr do
  @moduledoc since: "3.0.0"
  @moduledoc false

  alias Ecto.Query
  alias EctoShorts.QueryBinding

  require Ecto.Query

  @logger_prefix "EctoShorts.DynamicBuilders.Postgres.ArrayExpr"

  {target_binding_var, binding_patterns} = QueryBinding.query_binding_contracts(__MODULE__)

  for {quoted_binding_head, quoted_binding_body} <- binding_patterns do
    def dynamic_expr(unquote(quoted_binding_head) = selected_binding, key, negated, term, _opts) do
      selected_binding
      |> dispatch_expr(key, term)
      |> maybe_negate(negated)
    end

    defp field_dyn(unquote(quoted_binding_head), key) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        field(unquote(target_binding_var), ^key)
      )
    end

    defp nil_field_dyn?(unquote(quoted_binding_head), key) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        is_nil(field(unquote(target_binding_var), ^key))
      )
    end

    defp lower_exists_dyn(unquote(quoted_binding_head), key, value) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        fragment(
          "EXISTS (SELECT 1 FROM unnest(?) AS t WHERE lower(t) = ?)",
          field(unquote(target_binding_var), ^key),
          ^value
        )
      )
    end

    defp upper_exists_dyn(unquote(quoted_binding_head), key, value) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        fragment(
          "EXISTS (SELECT 1 FROM unnest(?) AS t WHERE upper(t) = ?)",
          field(unquote(target_binding_var), ^key),
          ^value
        )
      )
    end

    defp lower_not_exists_dyn(unquote(quoted_binding_head), key, value) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        fragment(
          "NOT EXISTS (SELECT 1 FROM unnest(?) AS t WHERE lower(t) = ?)",
          field(unquote(target_binding_var), ^key),
          ^value
        )
      )
    end

    defp upper_not_exists_dyn(unquote(quoted_binding_head), key, value) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        fragment(
          "NOT EXISTS (SELECT 1 FROM unnest(?) AS t WHERE upper(t) = ?)",
          field(unquote(target_binding_var), ^key),
          ^value
        )
      )
    end
  end

  def dynamic_expr(_selected_binding, _key, _negated, _term, _opts), do: nil

  defp dispatch_expr(binding, key, {:==, nil}) do
    nil_field_dyn?(binding, key)
  end

  defp dispatch_expr(binding, key, {:!=, nil}) do
    field = field_dyn(binding, key)
    Query.dynamic([], not is_nil(^field))
  end

  defp dispatch_expr(binding, key, {:==, values}) when is_list(values) do
    field = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], ^field == ^values)
  end

  defp dispatch_expr(binding, key, {:!=, values}) when is_list(values) do
    field = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], ^field != ^values)
  end

  defp dispatch_expr(binding, key, {:==, {:lower, value}}) do
    lower_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(binding, key, {:==, {:upper, value}}) do
    upper_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(binding, key, {:!=, {:lower, value}}) do
    lower_not_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(binding, key, {:!=, {:upper, value}}) do
    upper_not_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(_binding, key, {op, {:value, {arith_op, _}}})
       when op in [:==, :!=, :>, :>=, :<, :<=] and arith_op in [:+, :-, :*, :/] do
    EctoShorts.Logger.warning(
      @logger_prefix,
      "arithmetic comparison (#{arith_op}) is not supported on array field #{inspect(key)}, skipping"
    )

    nil
  end

  defp dispatch_expr(binding, key, {op, {:value, v}}) when op in [:==, :!=, :>, :>=, :<, :<=] do
    dispatch_expr(binding, key, {op, v})
  end

  defp dispatch_expr(binding, key, {:==, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field == any(qv))
  end

  defp dispatch_expr(binding, key, {:!=, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field != any(qv))
  end

  defp dispatch_expr(binding, key, {:>, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field > any(qv))
  end

  defp dispatch_expr(binding, key, {:>=, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field >= any(qv))
  end

  defp dispatch_expr(binding, key, {:<, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field < any(qv))
  end

  defp dispatch_expr(binding, key, {:<=, {:any, qv}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field <= any(qv))
  end

  defp dispatch_expr(binding, key, {:parent_as, {pb, pf}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field == field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:==, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field == field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:!=, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field != field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:>, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field > field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:>=, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field >= field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:<, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field < field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:<=, {:parent_as, {pb, pf}}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^field <= field(parent_as(^pb), ^pf))
  end

  defp dispatch_expr(binding, key, {:==, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^value in ^field)
  end

  defp dispatch_expr(binding, key, {:!=, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^value not in ^field)
  end

  defp dispatch_expr(binding, key, {:in, values}) when is_list(values) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? && ?", ^field, ^values))
  end

  defp dispatch_expr(binding, key, {:in, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], ^value in ^field)
  end

  defp dispatch_expr(binding, key, {:count, {:==, 0}}) do
    field = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], fragment("coalesce(array_length(?, 1), 0)", ^field) == ^0)
  end

  defp dispatch_expr(binding, key, {:count, {:==, value}}) do
    field = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], fragment("array_length(?, 1)", ^field) == ^value)
  end

  defp dispatch_expr(binding, key, {:count, {:!=, value}}) do
    field = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], fragment("array_length(?, 1)", ^field) != ^value)
  end

  defp dispatch_expr(binding, key, {:count, {:>, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("array_length(?, 1)", ^field) > ^value)
  end

  defp dispatch_expr(binding, key, {:count, {:>=, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("array_length(?, 1)", ^field) >= ^value)
  end

  defp dispatch_expr(binding, key, {:count, {:<, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("array_length(?, 1)", ^field) < ^value)
  end

  defp dispatch_expr(binding, key, {:count, {:<=, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("array_length(?, 1)", ^field) <= ^value)
  end

  defp dispatch_expr(binding, key, {:all, {:==, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? = ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:!=, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? != ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:>, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? < ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:>=, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? <= ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:<, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? > ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:<=, value}}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? >= ALL(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:all, {:in, values}}) when is_list(values) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? <@ ?", ^field, ^values))
  end

  defp dispatch_expr(binding, key, {:>, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? < ANY(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:>=, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? <= ANY(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:<, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? > ANY(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:<=, value}) do
    field = field_dyn(binding, key)
    Query.dynamic([], fragment("? >= ANY(?)", ^value, ^field))
  end

  defp dispatch_expr(binding, key, {:lower, value}) do
    lower_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(binding, key, {:upper, value}) do
    upper_exists_dyn(binding, key, value)
  end

  defp dispatch_expr(binding, key, {:like, value}) do
    field = field_dyn(binding, key)
    patterns = wrap_patterns(value)

    Query.dynamic(
      [],
      fragment("EXISTS (SELECT 1 FROM unnest(?) AS t WHERE t LIKE ANY (?))", ^field, ^patterns)
    )
  end

  defp dispatch_expr(binding, key, {:ilike, value}) do
    field = field_dyn(binding, key)
    patterns = wrap_patterns(value)

    Query.dynamic(
      [],
      fragment("EXISTS (SELECT 1 FROM unnest(?) AS t WHERE t ILIKE ANY (?))", ^field, ^patterns)
    )
  end

  defp dispatch_expr(_binding, key, {op, _}) when op in [:avg, :sum, :max, :min] do
    EctoShorts.Logger.warning(
      @logger_prefix,
      "#{op} aggregate is not supported on array field #{inspect(key)}, skipping"
    )

    nil
  end

  defp dispatch_expr(_binding, key, {:any, _}) do
    EctoShorts.Logger.warning(
      @logger_prefix,
      ":any subquery quantifier is not supported on array field #{inspect(key)}, skipping"
    )

    nil
  end

  defp dispatch_expr(_binding, key, {wrapper, _}) when wrapper in [:datetime, :date] do
    EctoShorts.Logger.warning(
      @logger_prefix,
      "#{wrapper} comparison is not supported on array field #{inspect(key)}, skipping"
    )

    nil
  end

  defp dispatch_expr(_binding, key, {:parent_as, _}) do
    EctoShorts.Logger.warning(
      @logger_prefix,
      ":parent_as requires a {binding, field} payload, got unexpected form for field #{inspect(key)}, skipping"
    )

    nil
  end

  defp dispatch_expr(_binding, _key, _term), do: nil

  defp maybe_negate(nil, _negated), do: nil
  defp maybe_negate(expr, :not), do: Query.dynamic([], not (^expr))
  defp maybe_negate(expr, _negated), do: expr

  defp wrap_patterns(values) when is_list(values) do
    Enum.map(values, &preserve_or_wrap_pattern/1)
  end

  defp wrap_patterns(value) do
    [preserve_or_wrap_pattern(value)]
  end

  defp preserve_or_wrap_pattern(value) when is_binary(value) do
    if String.contains?(value, ["%", "_"]) do
      value
    else
      "%#{value}%"
    end
  end

  defp preserve_or_wrap_pattern(value) do
    "%#{value}%"
  end
end
```

---

## Projected final state of `lib/ecto_shorts/dynamic_builders/postgres/map_expr.ex`

**No changes vs. current source.** `MapExpr` already dispatches on tuple IR (`{:contains, {k, v}}`, `{:has_key, value}`, etc.). The keyword-list JSONB fan-out mentioned in Change 3 (`|> Enum.map(fn kv -> MapExpr.dynamic_expr(...) end)`) is removed from `postgres.ex` because the walker already fans out each `{op, inner}` at the top level. `MapExpr` receives one tuple IR per call and pattern-matches — no map input, no `Map.to_list`, no normalization.

```elixir
defmodule EctoShorts.DynamicBuilders.Postgres.MapExpr do
  @moduledoc since: "3.0.0"
  @moduledoc false

  alias Ecto.Query
  alias EctoShorts.QueryBinding

  require Ecto.Query

  {target_binding_var, binding_patterns} =
    QueryBinding.query_binding_contracts(__MODULE__)

  for {quoted_binding_head, quoted_binding_body} <- binding_patterns do
    def dynamic_expr(unquote(quoted_binding_head) = selected_binding, key, negated, term, _opts) do
      selected_binding
      |> dispatch_expr(key, term)
      |> maybe_negate(negated)
    end

    defp field_dyn(unquote(quoted_binding_head), key) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        field(unquote(target_binding_var), ^key)
      )
    end

    defp nil_field_dyn(unquote(quoted_binding_head), key) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        is_nil(field(unquote(target_binding_var), ^key))
      )
    end
  end

  def dynamic_expr(_selected_binding, _key, _negated, _term, _opts), do: nil

  # Nil checks
  defp dispatch_expr(binding, key, {:==, nil}) do
    nil_field_dyn(binding, key)
  end

  defp dispatch_expr(binding, key, {:!=, nil}) do
    f = field_dyn(binding, key)
    Query.dynamic([], not is_nil(^f))
  end

  # Scalar equality/inequality
  defp dispatch_expr(binding, key, {:==, value}) do
    f = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], ^f == ^value)
  end

  defp dispatch_expr(binding, key, {:!=, value}) do
    f = field_dyn(binding, key)
    # credo:disable-for-next-line
    Query.dynamic([], ^f != ^value)
  end

  # JSONB containment — @>
  # Tuple form: produced by Normalizer from a single-entry map value.
  # e.g. %{contains: %{key: "value"}} → {:contains, {:key, "value"}}
  defp dispatch_expr(binding, key, {:contains, {k, v}}) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? @> ?::jsonb", ^f, ^%{k => v}))
  end

  # String form: caller-provided raw JSON string passed through unchanged.
  defp dispatch_expr(binding, key, {:contains, value}) when is_binary(value) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? @> ?::jsonb", ^f, ^value))
  end

  # List form: for array-typed JSONB values (e.g. JSON arrays).
  defp dispatch_expr(binding, key, {:contains, value}) when is_list(value) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? @> ?::jsonb", ^f, ^value))
  end

  # JSONB contained-by — <@
  defp dispatch_expr(binding, key, {:contained_by, {k, v}}) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? <@ ?::jsonb", ^f, ^%{k => v}))
  end

  defp dispatch_expr(binding, key, {:contained_by, value}) when is_binary(value) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? <@ ?::jsonb", ^f, ^value))
  end

  defp dispatch_expr(binding, key, {:contained_by, value}) when is_list(value) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("? <@ ?::jsonb", ^f, ^value))
  end

  # JSONB key existence — jsonb_exists(field, key)
  # Avoids the ? operator which conflicts with Ecto fragment placeholder syntax.
  defp dispatch_expr(binding, key, {:has_key, value}) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("jsonb_exists(?, ?)", ^f, ^value))
  end

  # JSONB any-key existence — jsonb_exists_any(field, keys)
  defp dispatch_expr(binding, key, {:has_any_key, values}) when is_list(values) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("jsonb_exists_any(?, ?)", ^f, ^values))
  end

  # JSONB all-keys existence — jsonb_exists_all(field, keys)
  defp dispatch_expr(binding, key, {:has_all_keys, values}) when is_list(values) do
    f = field_dyn(binding, key)
    Query.dynamic([], fragment("jsonb_exists_all(?, ?)", ^f, ^values))
  end

  defp dispatch_expr(_binding, _key, _term), do: nil

  defp maybe_negate(nil, _negated), do: nil
  defp maybe_negate(expr, :not), do: Query.dynamic([], not (^expr))
  defp maybe_negate(expr, _negated), do: expr
end
```

---

## Projected final state of `lib/ecto_shorts/dynamic_builders/postgres/common_expr.ex`

**No changes vs. current source.** The module's public contract (`dynamic_expr(binding, operator, negated, term, opts)`) is unchanged and is called from the new key-guarded clause in `Postgres.evaluate_field/6`. The term shape handed in (the raw cursor value, datetime, or subquery) matches the existing `dispatch_expr/3` clauses. No casting is added here — common-expr values are already typed.

```elixir
defmodule EctoShorts.DynamicBuilders.Postgres.CommonExpr do
  @moduledoc since: "3.0.0"
  @moduledoc false

  alias Ecto.Query
  alias EctoShorts.QueryBinding

  require Ecto.Query

  @operators [
    :ids,
    :before,
    :after,
    :until,
    :since,
    :exists,
    :start_date,
    :end_date,
    :since_date,
    :until_date
  ]

  def operators, do: @operators

  {target_binding_var, binding_patterns} = QueryBinding.query_binding_contracts(__MODULE__)

  for {quoted_binding_head, quoted_binding_body} <- binding_patterns do
    def dynamic_expr(
          unquote(quoted_binding_head) = selected_binding,
          operator,
          negated,
          term,
          _opts
        ) do
      selected_binding
      |> dispatch_expr(operator, term)
      |> maybe_negate(negated)
    end

    defp field_dyn(unquote(quoted_binding_head), field_name) do
      Query.dynamic(
        [unquote_splicing(quoted_binding_body)],
        field(unquote(target_binding_var), ^field_name)
      )
    end
  end

  def dynamic_expr(_selected_binding, _operator, _negated, _term, _opts), do: nil

  defp dispatch_expr(binding, :ids, term) do
    dyn = field_dyn(binding, :id)
    Query.dynamic([], ^dyn in ^term)
  end

  defp dispatch_expr(binding, :after, term) do
    dyn = field_dyn(binding, :id)
    Query.dynamic([], ^dyn > ^term)
  end

  defp dispatch_expr(binding, :before, term) do
    dyn = field_dyn(binding, :id)
    Query.dynamic([], ^dyn < ^term)
  end

  defp dispatch_expr(binding, :since, term) do
    dyn = field_dyn(binding, :id)
    Query.dynamic([], ^dyn >= ^term)
  end

  defp dispatch_expr(binding, :until, term) do
    dyn = field_dyn(binding, :id)
    Query.dynamic([], ^dyn <= ^term)
  end

  defp dispatch_expr(binding, operator, term) when operator in [:start_date, :since_date] do
    dyn = field_dyn(binding, :inserted_at)
    Query.dynamic([], ^dyn >= ^term)
  end

  defp dispatch_expr(binding, operator, term) when operator in [:end_date, :until_date] do
    dyn = field_dyn(binding, :inserted_at)
    Query.dynamic([], ^dyn <= ^term)
  end

  defp dispatch_expr(_binding, :exists, term) do
    Query.dynamic([], exists(term))
  end

  defp dispatch_expr(_binding, _operator, _term), do: nil

  defp maybe_negate(nil, _negated), do: nil
  defp maybe_negate(expr, :not), do: Query.dynamic([], not (^expr))
  defp maybe_negate(expr, _negated), do: expr
end
```

---

## Verification

```bash
mix test test/ecto_shorts/dynamic_builders/
mix test test/ecto_shorts/common_filters/
mix test test/ecto_shorts/common_filters_schemaless/
mix test
mix credo
```
